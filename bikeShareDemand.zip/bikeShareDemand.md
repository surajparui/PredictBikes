# Predict Bike Sharing Demand with AutoGluon Template

## Project: Predict Bike Sharing Demand with AutoGluon
This notebook is a template with each step that you need to complete for the project.

Please fill in your code where there are explicit `?` markers in the notebook. You are welcome to add more cells and code as you see fit.

Once you have completed all the code implementations, please export your notebook as a HTML file so the reviews can view your code. Make sure you have all outputs correctly outputted.

`File-> Export Notebook As... -> Export Notebook as HTML`

There is a writeup to complete as well after all code implememtation is done. Please answer all questions and attach the necessary tables and charts. You can complete the writeup in either markdown or PDF.

Completing the code template and writeup template will cover all of the rubric points for this project.

The rubric contains "Stand Out Suggestions" for enhancing the project beyond the minimum requirements. The stand out suggestions are optional. If you decide to pursue the "stand out suggestions", you can include the code in this notebook and also discuss the results in the writeup file.


```python
!pip install nbconvert
```

    Requirement already satisfied: nbconvert in /opt/conda/lib/python3.7/site-packages (6.5.4)
    Requirement already satisfied: nbformat>=5.1 in /opt/conda/lib/python3.7/site-packages (from nbconvert) (5.8.0)
    Requirement already satisfied: jupyterlab-pygments in /opt/conda/lib/python3.7/site-packages (from nbconvert) (0.2.2)
    Requirement already satisfied: nbclient>=0.5.0 in /opt/conda/lib/python3.7/site-packages (from nbconvert) (0.7.3)
    Requirement already satisfied: beautifulsoup4 in /opt/conda/lib/python3.7/site-packages (from nbconvert) (4.8.2)
    Requirement already satisfied: pandocfilters>=1.4.1 in /opt/conda/lib/python3.7/site-packages (from nbconvert) (1.4.2)
    Requirement already satisfied: MarkupSafe>=2.0 in /opt/conda/lib/python3.7/site-packages (from nbconvert) (2.1.2)
    Requirement already satisfied: packaging in /opt/conda/lib/python3.7/site-packages (from nbconvert) (20.1)
    Requirement already satisfied: pygments>=2.4.1 in /opt/conda/lib/python3.7/site-packages (from nbconvert) (2.15.0)
    Requirement already satisfied: traitlets>=5.0 in /opt/conda/lib/python3.7/site-packages (from nbconvert) (5.9.0)
    Requirement already satisfied: defusedxml in /opt/conda/lib/python3.7/site-packages (from nbconvert) (0.6.0)
    Requirement already satisfied: jinja2>=3.0 in /opt/conda/lib/python3.7/site-packages (from nbconvert) (3.1.2)
    Requirement already satisfied: tinycss2 in /opt/conda/lib/python3.7/site-packages (from nbconvert) (1.2.1)
    Requirement already satisfied: entrypoints>=0.2.2 in /opt/conda/lib/python3.7/site-packages (from nbconvert) (0.3)
    Requirement already satisfied: mistune<2,>=0.8.1 in /opt/conda/lib/python3.7/site-packages (from nbconvert) (0.8.4)
    Requirement already satisfied: jupyter-core>=4.7 in /opt/conda/lib/python3.7/site-packages (from nbconvert) (4.12.0)
    Requirement already satisfied: lxml in /opt/conda/lib/python3.7/site-packages (from nbconvert) (4.9.2)
    Requirement already satisfied: bleach in /opt/conda/lib/python3.7/site-packages (from nbconvert) (6.0.0)
    Requirement already satisfied: jupyter-client>=6.1.12 in /opt/conda/lib/python3.7/site-packages (from nbclient>=0.5.0->nbconvert) (7.4.9)
    Requirement already satisfied: fastjsonschema in /opt/conda/lib/python3.7/site-packages (from nbformat>=5.1->nbconvert) (2.16.3)
    Requirement already satisfied: jsonschema>=2.6 in /opt/conda/lib/python3.7/site-packages (from nbformat>=5.1->nbconvert) (3.2.0)
    Requirement already satisfied: importlib-metadata>=3.6 in /opt/conda/lib/python3.7/site-packages (from nbformat>=5.1->nbconvert) (6.3.0)
    Requirement already satisfied: soupsieve>=1.2 in /opt/conda/lib/python3.7/site-packages (from beautifulsoup4->nbconvert) (1.9.5)
    Requirement already satisfied: webencodings in /opt/conda/lib/python3.7/site-packages (from bleach->nbconvert) (0.5.1)
    Requirement already satisfied: six>=1.9.0 in /opt/conda/lib/python3.7/site-packages (from bleach->nbconvert) (1.14.0)
    Requirement already satisfied: pyparsing>=2.0.2 in /opt/conda/lib/python3.7/site-packages (from packaging->nbconvert) (2.4.6)
    Requirement already satisfied: zipp>=0.5 in /opt/conda/lib/python3.7/site-packages (from importlib-metadata>=3.6->nbformat>=5.1->nbconvert) (3.15.0)
    Requirement already satisfied: typing-extensions>=3.6.4 in /opt/conda/lib/python3.7/site-packages (from importlib-metadata>=3.6->nbformat>=5.1->nbconvert) (4.5.0)
    Requirement already satisfied: setuptools in /opt/conda/lib/python3.7/site-packages (from jsonschema>=2.6->nbformat>=5.1->nbconvert) (59.3.0)
    Requirement already satisfied: attrs>=17.4.0 in /opt/conda/lib/python3.7/site-packages (from jsonschema>=2.6->nbformat>=5.1->nbconvert) (22.2.0)
    Requirement already satisfied: pyrsistent>=0.14.0 in /opt/conda/lib/python3.7/site-packages (from jsonschema>=2.6->nbformat>=5.1->nbconvert) (0.15.7)
    Requirement already satisfied: python-dateutil>=2.8.2 in /opt/conda/lib/python3.7/site-packages (from jupyter-client>=6.1.12->nbclient>=0.5.0->nbconvert) (2.8.2)
    Requirement already satisfied: tornado>=6.2 in /opt/conda/lib/python3.7/site-packages (from jupyter-client>=6.1.12->nbclient>=0.5.0->nbconvert) (6.2)
    Requirement already satisfied: pyzmq>=23.0 in /opt/conda/lib/python3.7/site-packages (from jupyter-client>=6.1.12->nbclient>=0.5.0->nbconvert) (25.0.2)
    Requirement already satisfied: nest-asyncio>=1.5.4 in /opt/conda/lib/python3.7/site-packages (from jupyter-client>=6.1.12->nbclient>=0.5.0->nbconvert) (1.5.6)
    [33mWARNING: Running pip as the 'root' user can result in broken permissions and conflicting behaviour with the system package manager. It is recommended to use a virtual environment instead: https://pip.pypa.io/warnings/venv[0m[33m
    [0m
    [1m[[0m[34;49mnotice[0m[1;39;49m][0m[39;49m A new release of pip is available: [0m[31;49m23.0.1[0m[39;49m -> [0m[32;49m23.1.2[0m
    [1m[[0m[34;49mnotice[0m[1;39;49m][0m[39;49m To update, run: [0m[32;49mpip install --upgrade pip[0m



```python
!pip install --upgrade pip

```

    Requirement already satisfied: pip in /opt/conda/lib/python3.7/site-packages (23.0.1)
    Collecting pip
      Using cached pip-23.1.2-py3-none-any.whl (2.1 MB)
    Installing collected packages: pip
      Attempting uninstall: pip
        Found existing installation: pip 23.0.1
        Uninstalling pip-23.0.1:
          Successfully uninstalled pip-23.0.1
    Successfully installed pip-23.1.2
    [33mWARNING: Running pip as the 'root' user can result in broken permissions and conflicting behaviour with the system package manager. It is recommended to use a virtual environment instead: https://pip.pypa.io/warnings/venv[0m[33m
    [0m

## Step 1: Create an account with Kaggle

### Create Kaggle Account and download API key
Below is example of steps to get the API username and key. Each student will have their own username and key.



## Step 2: Download the Kaggle dataset using the kaggle python library

### Open up Sagemaker Studio and use starter template

1. Notebook should be using a `ml.t3.medium` instance (2 vCPU + 4 GiB)
2. Notebook should be using kernal: `Python 3 (MXNet 1.8 Python 3.7 CPU Optimized)`

### Install packages


```python
!pip install -U pip
!pip install ipython
!pip install -U setuptools wheel
!pip install -U "mxnet<2.0.0" bokeh==2.0.1
!pip install autogluon --no-cache-dir
# Without --no-cache-dir, smaller aws instances may have trouble installing
```

    Looking in indexes: https://pypi.org/simple, https://us-python.pkg.dev/colab-wheels/public/simple/
    Requirement already satisfied: pip in /usr/local/lib/python3.10/dist-packages (23.1.2)
    Looking in indexes: https://pypi.org/simple, https://us-python.pkg.dev/colab-wheels/public/simple/
    Requirement already satisfied: ipython in /usr/local/lib/python3.10/dist-packages (7.34.0)
    Requirement already satisfied: setuptools>=18.5 in /usr/local/lib/python3.10/dist-packages (from ipython) (67.8.0)
    Collecting jedi>=0.16 (from ipython)
      Downloading jedi-0.18.2-py2.py3-none-any.whl (1.6 MB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m1.6/1.6 MB[0m [31m21.4 MB/s[0m eta [36m0:00:00[0m
    [?25hRequirement already satisfied: decorator in /usr/local/lib/python3.10/dist-packages (from ipython) (4.4.2)
    Requirement already satisfied: pickleshare in /usr/local/lib/python3.10/dist-packages (from ipython) (0.7.5)
    Requirement already satisfied: traitlets>=4.2 in /usr/local/lib/python3.10/dist-packages (from ipython) (5.7.1)
    Requirement already satisfied: prompt-toolkit!=3.0.0,!=3.0.1,<3.1.0,>=2.0.0 in /usr/local/lib/python3.10/dist-packages (from ipython) (3.0.38)
    Requirement already satisfied: pygments in /usr/local/lib/python3.10/dist-packages (from ipython) (2.14.0)
    Requirement already satisfied: backcall in /usr/local/lib/python3.10/dist-packages (from ipython) (0.2.0)
    Requirement already satisfied: matplotlib-inline in /usr/local/lib/python3.10/dist-packages (from ipython) (0.1.6)
    Requirement already satisfied: pexpect>4.3 in /usr/local/lib/python3.10/dist-packages (from ipython) (4.8.0)
    Requirement already satisfied: parso<0.9.0,>=0.8.0 in /usr/local/lib/python3.10/dist-packages (from jedi>=0.16->ipython) (0.8.3)
    Requirement already satisfied: ptyprocess>=0.5 in /usr/local/lib/python3.10/dist-packages (from pexpect>4.3->ipython) (0.7.0)
    Requirement already satisfied: wcwidth in /usr/local/lib/python3.10/dist-packages (from prompt-toolkit!=3.0.0,!=3.0.1,<3.1.0,>=2.0.0->ipython) (0.2.6)
    Installing collected packages: jedi
    Successfully installed jedi-0.18.2
    Looking in indexes: https://pypi.org/simple, https://us-python.pkg.dev/colab-wheels/public/simple/
    Requirement already satisfied: setuptools in /usr/local/lib/python3.10/dist-packages (67.8.0)
    Requirement already satisfied: wheel in /usr/local/lib/python3.10/dist-packages (0.40.0)
    Looking in indexes: https://pypi.org/simple, https://us-python.pkg.dev/colab-wheels/public/simple/
    Requirement already satisfied: mxnet<2.0.0 in /usr/local/lib/python3.10/dist-packages (1.9.1)
    Requirement already satisfied: bokeh==2.0.1 in /usr/local/lib/python3.10/dist-packages (2.0.1)
    Requirement already satisfied: PyYAML>=3.10 in /usr/local/lib/python3.10/dist-packages (from bokeh==2.0.1) (6.0)
    Requirement already satisfied: python-dateutil>=2.1 in /usr/local/lib/python3.10/dist-packages (from bokeh==2.0.1) (2.8.2)
    Requirement already satisfied: Jinja2>=2.7 in /usr/local/lib/python3.10/dist-packages (from bokeh==2.0.1) (3.1.2)
    Requirement already satisfied: numpy>=1.11.3 in /usr/local/lib/python3.10/dist-packages (from bokeh==2.0.1) (1.22.4)
    Requirement already satisfied: pillow>=4.0 in /usr/local/lib/python3.10/dist-packages (from bokeh==2.0.1) (8.4.0)
    Requirement already satisfied: packaging>=16.8 in /usr/local/lib/python3.10/dist-packages (from bokeh==2.0.1) (23.1)
    Requirement already satisfied: tornado>=5 in /usr/local/lib/python3.10/dist-packages (from bokeh==2.0.1) (6.3.1)
    Requirement already satisfied: typing-extensions>=3.7.4 in /usr/local/lib/python3.10/dist-packages (from bokeh==2.0.1) (4.5.0)
    Requirement already satisfied: requests<3,>=2.20.0 in /usr/local/lib/python3.10/dist-packages (from mxnet<2.0.0) (2.27.1)
    Requirement already satisfied: graphviz<0.9.0,>=0.8.1 in /usr/local/lib/python3.10/dist-packages (from mxnet<2.0.0) (0.8.4)
    Requirement already satisfied: MarkupSafe>=2.0 in /usr/local/lib/python3.10/dist-packages (from Jinja2>=2.7->bokeh==2.0.1) (2.1.2)
    Requirement already satisfied: six>=1.5 in /usr/local/lib/python3.10/dist-packages (from python-dateutil>=2.1->bokeh==2.0.1) (1.16.0)
    Requirement already satisfied: urllib3<1.27,>=1.21.1 in /usr/local/lib/python3.10/dist-packages (from requests<3,>=2.20.0->mxnet<2.0.0) (1.26.15)
    Requirement already satisfied: certifi>=2017.4.17 in /usr/local/lib/python3.10/dist-packages (from requests<3,>=2.20.0->mxnet<2.0.0) (2022.12.7)
    Requirement already satisfied: charset-normalizer~=2.0.0 in /usr/local/lib/python3.10/dist-packages (from requests<3,>=2.20.0->mxnet<2.0.0) (2.0.12)
    Requirement already satisfied: idna<4,>=2.5 in /usr/local/lib/python3.10/dist-packages (from requests<3,>=2.20.0->mxnet<2.0.0) (3.4)
    Looking in indexes: https://pypi.org/simple, https://us-python.pkg.dev/colab-wheels/public/simple/
    Collecting autogluon
      Downloading autogluon-0.7.0-py3-none-any.whl (9.7 kB)
    Collecting autogluon.core[all]==0.7.0 (from autogluon)
      Downloading autogluon.core-0.7.0-py3-none-any.whl (218 kB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m218.3/218.3 kB[0m [31m8.8 MB/s[0m eta [36m0:00:00[0m
    [?25hCollecting autogluon.features==0.7.0 (from autogluon)
      Downloading autogluon.features-0.7.0-py3-none-any.whl (60 kB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m60.1/60.1 kB[0m [31m220.4 MB/s[0m eta [36m0:00:00[0m
    [?25hCollecting autogluon.tabular[all]==0.7.0 (from autogluon)
      Downloading autogluon.tabular-0.7.0-py3-none-any.whl (292 kB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m292.2/292.2 kB[0m [31m43.3 MB/s[0m eta [36m0:00:00[0m
    [?25hCollecting autogluon.multimodal==0.7.0 (from autogluon)
      Downloading autogluon.multimodal-0.7.0-py3-none-any.whl (331 kB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m331.1/331.1 kB[0m [31m303.6 MB/s[0m eta [36m0:00:00[0m
    [?25hCollecting autogluon.timeseries[all]==0.7.0 (from autogluon)
      Downloading autogluon.timeseries-0.7.0-py3-none-any.whl (108 kB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m108.7/108.7 kB[0m [31m249.9 MB/s[0m eta [36m0:00:00[0m
    [?25hRequirement already satisfied: numpy<1.27,>=1.21 in /usr/local/lib/python3.10/dist-packages (from autogluon.core[all]==0.7.0->autogluon) (1.22.4)
    Requirement already satisfied: scipy<1.12,>=1.5.4 in /usr/local/lib/python3.10/dist-packages (from autogluon.core[all]==0.7.0->autogluon) (1.10.1)
    Requirement already satisfied: scikit-learn<1.3,>=1.0 in /usr/local/lib/python3.10/dist-packages (from autogluon.core[all]==0.7.0->autogluon) (1.2.2)
    Collecting networkx<3.0,>=2.3 (from autogluon.core[all]==0.7.0->autogluon)
      Downloading networkx-2.8.8-py3-none-any.whl (2.0 MB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m2.0/2.0 MB[0m [31m165.6 MB/s[0m eta [36m0:00:00[0m
    [?25hRequirement already satisfied: pandas<1.6,>=1.4.1 in /usr/local/lib/python3.10/dist-packages (from autogluon.core[all]==0.7.0->autogluon) (1.5.3)
    Requirement already satisfied: tqdm<5,>=4.38 in /usr/local/lib/python3.10/dist-packages (from autogluon.core[all]==0.7.0->autogluon) (4.65.0)
    Requirement already satisfied: requests in /usr/local/lib/python3.10/dist-packages (from autogluon.core[all]==0.7.0->autogluon) (2.27.1)
    Requirement already satisfied: matplotlib in /usr/local/lib/python3.10/dist-packages (from autogluon.core[all]==0.7.0->autogluon) (3.7.1)
    Collecting boto3<2,>=1.10 (from autogluon.core[all]==0.7.0->autogluon)
      Downloading boto3-1.26.137-py3-none-any.whl (135 kB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m135.6/135.6 kB[0m [31m183.6 MB/s[0m eta [36m0:00:00[0m
    [?25hCollecting autogluon.common==0.7.0 (from autogluon.core[all]==0.7.0->autogluon)
      Downloading autogluon.common-0.7.0-py3-none-any.whl (45 kB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m45.0/45.0 kB[0m [31m148.1 MB/s[0m eta [36m0:00:00[0m
    [?25hRequirement already satisfied: hyperopt<0.2.8,>=0.2.7 in /usr/local/lib/python3.10/dist-packages (from autogluon.core[all]==0.7.0->autogluon) (0.2.7)
    Collecting ray[tune]<2.3,>=2.2 (from autogluon.core[all]==0.7.0->autogluon)
      Downloading ray-2.2.0-cp310-cp310-manylinux2014_x86_64.whl (57.4 MB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m57.4/57.4 MB[0m [31m161.6 MB/s[0m eta [36m0:00:00[0m
    [?25hCollecting Pillow<9.6,>=9.3 (from autogluon.multimodal==0.7.0->autogluon)
      Downloading Pillow-9.5.0-cp310-cp310-manylinux_2_28_x86_64.whl (3.4 MB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m3.4/3.4 MB[0m [31m291.2 MB/s[0m eta [36m0:00:00[0m
    [?25hCollecting jsonschema<4.18,>=4.14 (from autogluon.multimodal==0.7.0->autogluon)
      Downloading jsonschema-4.17.3-py3-none-any.whl (90 kB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m90.4/90.4 kB[0m [31m251.7 MB/s[0m eta [36m0:00:00[0m
    [?25hCollecting seqeval<1.3.0,>=1.2.2 (from autogluon.multimodal==0.7.0->autogluon)
      Downloading seqeval-1.2.2.tar.gz (43 kB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m43.6/43.6 kB[0m [31m151.8 MB/s[0m eta [36m0:00:00[0m
    [?25h  Preparing metadata (setup.py) ... [?25l[?25hdone
    Collecting evaluate<0.4.0,>=0.2.2 (from autogluon.multimodal==0.7.0->autogluon)
      Downloading evaluate-0.3.0-py3-none-any.whl (72 kB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m72.9/72.9 kB[0m [31m259.7 MB/s[0m eta [36m0:00:00[0m
    [?25hCollecting accelerate<0.17,>=0.9 (from autogluon.multimodal==0.7.0->autogluon)
      Downloading accelerate-0.16.0-py3-none-any.whl (199 kB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m199.7/199.7 kB[0m [31m300.1 MB/s[0m eta [36m0:00:00[0m
    [?25hCollecting timm<0.7.0,>=0.6.12 (from autogluon.multimodal==0.7.0->autogluon)
      Downloading timm-0.6.13-py3-none-any.whl (549 kB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m549.1/549.1 kB[0m [31m342.8 MB/s[0m eta [36m0:00:00[0m
    [?25hCollecting torch<1.14,>=1.9 (from autogluon.multimodal==0.7.0->autogluon)
      Downloading torch-1.13.1-cp310-cp310-manylinux1_x86_64.whl (887.5 MB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m887.5/887.5 MB[0m [31m84.0 MB/s[0m eta [36m0:00:00[0m
    [?25hCollecting torchvision<0.15.0 (from autogluon.multimodal==0.7.0->autogluon)
      Downloading torchvision-0.14.1-cp310-cp310-manylinux1_x86_64.whl (24.2 MB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m24.2/24.2 MB[0m [31m171.1 MB/s[0m eta [36m0:00:00[0m
    [?25hCollecting fairscale<0.4.14,>=0.4.5 (from autogluon.multimodal==0.7.0->autogluon)
      Downloading fairscale-0.4.13.tar.gz (266 kB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m266.3/266.3 kB[0m [31m321.5 MB/s[0m eta [36m0:00:00[0m
    [?25h  Installing build dependencies ... [?25l[?25hdone
      Getting requirements to build wheel ... [?25l[?25hdone
      Installing backend dependencies ... [?25l[?25hdone
      Preparing metadata (pyproject.toml) ... [?25l[?25hdone
    Requirement already satisfied: scikit-image<0.20.0,>=0.19.1 in /usr/local/lib/python3.10/dist-packages (from autogluon.multimodal==0.7.0->autogluon) (0.19.3)
    Collecting pytorch-lightning<1.10.0,>=1.9.0 (from autogluon.multimodal==0.7.0->autogluon)
      Downloading pytorch_lightning-1.9.5-py3-none-any.whl (829 kB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m829.5/829.5 kB[0m [31m340.1 MB/s[0m eta [36m0:00:00[0m
    [?25hRequirement already satisfied: text-unidecode<1.4,>=1.3 in /usr/local/lib/python3.10/dist-packages (from autogluon.multimodal==0.7.0->autogluon) (1.3)
    Collecting torchmetrics<0.9.0,>=0.8.0 (from autogluon.multimodal==0.7.0->autogluon)
      Downloading torchmetrics-0.8.2-py3-none-any.whl (409 kB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m409.8/409.8 kB[0m [31m310.2 MB/s[0m eta [36m0:00:00[0m
    [?25hCollecting transformers<4.27.0,>=4.23.0 (from autogluon.multimodal==0.7.0->autogluon)
      Downloading transformers-4.26.1-py3-none-any.whl (6.3 MB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m6.3/6.3 MB[0m [31m241.6 MB/s[0m eta [36m0:00:00[0m
    [?25hCollecting nptyping<2.5.0,>=1.4.4 (from autogluon.multimodal==0.7.0->autogluon)
      Downloading nptyping-2.4.1-py3-none-any.whl (36 kB)
    Collecting omegaconf<2.3.0,>=2.1.1 (from autogluon.multimodal==0.7.0->autogluon)
      Downloading omegaconf-2.2.3-py3-none-any.whl (79 kB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m79.3/79.3 kB[0m [31m162.8 MB/s[0m eta [36m0:00:00[0m
    [?25hCollecting sentencepiece<0.2.0,>=0.1.95 (from autogluon.multimodal==0.7.0->autogluon)
      Downloading sentencepiece-0.1.99-cp310-cp310-manylinux_2_17_x86_64.manylinux2014_x86_64.whl (1.3 MB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m1.3/1.3 MB[0m [31m347.6 MB/s[0m eta [36m0:00:00[0m
    [?25hCollecting pytorch-metric-learning<2.0,>=1.3.0 (from autogluon.multimodal==0.7.0->autogluon)
      Downloading pytorch_metric_learning-1.7.3-py3-none-any.whl (112 kB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m112.2/112.2 kB[0m [31m282.2 MB/s[0m eta [36m0:00:00[0m
    [?25hCollecting nlpaug<1.2.0,>=1.1.10 (from autogluon.multimodal==0.7.0->autogluon)
      Downloading nlpaug-1.1.11-py3-none-any.whl (410 kB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m410.5/410.5 kB[0m [31m324.3 MB/s[0m eta [36m0:00:00[0m
    [?25hRequirement already satisfied: nltk<4.0.0,>=3.4.5 in /usr/local/lib/python3.10/dist-packages (from autogluon.multimodal==0.7.0->autogluon) (3.8.1)
    Collecting openmim<0.4.0,>0.1.5 (from autogluon.multimodal==0.7.0->autogluon)
      Downloading openmim-0.3.7-py2.py3-none-any.whl (51 kB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m51.3/51.3 kB[0m [31m158.6 MB/s[0m eta [36m0:00:00[0m
    [?25hRequirement already satisfied: defusedxml<0.7.2,>=0.7.1 in /usr/local/lib/python3.10/dist-packages (from autogluon.multimodal==0.7.0->autogluon) (0.7.1)
    Requirement already satisfied: jinja2<3.2,>=3.0.3 in /usr/local/lib/python3.10/dist-packages (from autogluon.multimodal==0.7.0->autogluon) (3.1.2)
    Requirement already satisfied: tensorboard<3,>=2.9 in /usr/local/lib/python3.10/dist-packages (from autogluon.multimodal==0.7.0->autogluon) (2.12.2)
    Collecting pytesseract<0.3.11,>=0.3.9 (from autogluon.multimodal==0.7.0->autogluon)
      Downloading pytesseract-0.3.10-py3-none-any.whl (14 kB)
    Collecting catboost<1.2,>=1.0 (from autogluon.tabular[all]==0.7.0->autogluon)
      Downloading catboost-1.1.1-cp310-none-manylinux1_x86_64.whl (76.6 MB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m76.6/76.6 MB[0m [31m156.9 MB/s[0m eta [36m0:00:00[0m
    [?25hRequirement already satisfied: lightgbm<3.4,>=3.3 in /usr/local/lib/python3.10/dist-packages (from autogluon.tabular[all]==0.7.0->autogluon) (3.3.5)
    Requirement already satisfied: xgboost<1.8,>=1.6 in /usr/local/lib/python3.10/dist-packages (from autogluon.tabular[all]==0.7.0->autogluon) (1.7.5)
    Requirement already satisfied: fastai<2.8,>=2.3.1 in /usr/local/lib/python3.10/dist-packages (from autogluon.tabular[all]==0.7.0->autogluon) (2.7.12)
    Requirement already satisfied: joblib<2,>=1.1 in /usr/local/lib/python3.10/dist-packages (from autogluon.timeseries[all]==0.7.0->autogluon) (1.2.0)
    Requirement already satisfied: statsmodels<0.14,>=0.13.0 in /usr/local/lib/python3.10/dist-packages (from autogluon.timeseries[all]==0.7.0->autogluon) (0.13.5)
    Collecting gluonts<0.13,>=0.12.0 (from autogluon.timeseries[all]==0.7.0->autogluon)
      Downloading gluonts-0.12.8-py3-none-any.whl (1.2 MB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m1.2/1.2 MB[0m [31m151.8 MB/s[0m eta [36m0:00:00[0m
    [?25hCollecting statsforecast<1.5,>=1.4.0 (from autogluon.timeseries[all]==0.7.0->autogluon)
      Downloading statsforecast-1.4.0-py3-none-any.whl (91 kB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m92.0/92.0 kB[0m [31m186.6 MB/s[0m eta [36m0:00:00[0m
    [?25hCollecting ujson<6,>=5 (from autogluon.timeseries[all]==0.7.0->autogluon)
      Downloading ujson-5.7.0-cp310-cp310-manylinux_2_17_x86_64.manylinux2014_x86_64.whl (52 kB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m52.8/52.8 kB[0m [31m99.8 MB/s[0m eta [36m0:00:00[0m
    [?25hCollecting sktime<0.16,>=0.14 (from autogluon.timeseries[all]==0.7.0->autogluon)
      Downloading sktime-0.15.1-py3-none-any.whl (16.0 MB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m16.0/16.0 MB[0m [31m149.8 MB/s[0m eta [36m0:00:00[0m
    [?25hCollecting tbats<2,>=1.1 (from autogluon.timeseries[all]==0.7.0->autogluon)
      Downloading tbats-1.1.3-py3-none-any.whl (44 kB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m44.0/44.0 kB[0m [31m103.4 MB/s[0m eta [36m0:00:00[0m
    [?25hCollecting pmdarima<1.9,>=1.8.2 (from autogluon.timeseries[all]==0.7.0->autogluon)
      Downloading pmdarima-1.8.5-cp310-cp310-manylinux_2_17_x86_64.manylinux2014_x86_64.manylinux_2_24_x86_64.whl (1.4 MB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m1.4/1.4 MB[0m [31m170.6 MB/s[0m eta [36m0:00:00[0m
    [?25hRequirement already satisfied: psutil<6,>=5.7.3 in /usr/local/lib/python3.10/dist-packages (from autogluon.common==0.7.0->autogluon.core[all]==0.7.0->autogluon) (5.9.5)
    Requirement already satisfied: setuptools in /usr/local/lib/python3.10/dist-packages (from autogluon.common==0.7.0->autogluon.core[all]==0.7.0->autogluon) (67.8.0)
    Requirement already satisfied: packaging>=20.0 in /usr/local/lib/python3.10/dist-packages (from accelerate<0.17,>=0.9->autogluon.multimodal==0.7.0->autogluon) (23.1)
    Requirement already satisfied: pyyaml in /usr/local/lib/python3.10/dist-packages (from accelerate<0.17,>=0.9->autogluon.multimodal==0.7.0->autogluon) (6.0)
    Collecting botocore<1.30.0,>=1.29.137 (from boto3<2,>=1.10->autogluon.core[all]==0.7.0->autogluon)
      Downloading botocore-1.29.137-py3-none-any.whl (10.8 MB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m10.8/10.8 MB[0m [31m214.3 MB/s[0m eta [36m0:00:00[0m
    [?25hCollecting jmespath<2.0.0,>=0.7.1 (from boto3<2,>=1.10->autogluon.core[all]==0.7.0->autogluon)
      Downloading jmespath-1.0.1-py3-none-any.whl (20 kB)
    Collecting s3transfer<0.7.0,>=0.6.0 (from boto3<2,>=1.10->autogluon.core[all]==0.7.0->autogluon)
      Downloading s3transfer-0.6.1-py3-none-any.whl (79 kB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m79.8/79.8 kB[0m [31m192.5 MB/s[0m eta [36m0:00:00[0m
    [?25hRequirement already satisfied: graphviz in /usr/local/lib/python3.10/dist-packages (from catboost<1.2,>=1.0->autogluon.tabular[all]==0.7.0->autogluon) (0.8.4)
    Requirement already satisfied: plotly in /usr/local/lib/python3.10/dist-packages (from catboost<1.2,>=1.0->autogluon.tabular[all]==0.7.0->autogluon) (5.13.1)
    Requirement already satisfied: six in /usr/local/lib/python3.10/dist-packages (from catboost<1.2,>=1.0->autogluon.tabular[all]==0.7.0->autogluon) (1.16.0)
    Collecting datasets>=2.0.0 (from evaluate<0.4.0,>=0.2.2->autogluon.multimodal==0.7.0->autogluon)
      Downloading datasets-2.12.0-py3-none-any.whl (474 kB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m474.6/474.6 kB[0m [31m239.2 MB/s[0m eta [36m0:00:00[0m
    [?25hCollecting dill (from evaluate<0.4.0,>=0.2.2->autogluon.multimodal==0.7.0->autogluon)
      Downloading dill-0.3.6-py3-none-any.whl (110 kB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m110.5/110.5 kB[0m [31m284.5 MB/s[0m eta [36m0:00:00[0m
    [?25hCollecting xxhash (from evaluate<0.4.0,>=0.2.2->autogluon.multimodal==0.7.0->autogluon)
      Downloading xxhash-3.2.0-cp310-cp310-manylinux_2_17_x86_64.manylinux2014_x86_64.whl (212 kB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m212.5/212.5 kB[0m [31m213.3 MB/s[0m eta [36m0:00:00[0m
    [?25hCollecting multiprocess (from evaluate<0.4.0,>=0.2.2->autogluon.multimodal==0.7.0->autogluon)
      Downloading multiprocess-0.70.14-py310-none-any.whl (134 kB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m134.3/134.3 kB[0m [31m175.9 MB/s[0m eta [36m0:00:00[0m
    [?25hRequirement already satisfied: fsspec[http]>=2021.05.0 in /usr/local/lib/python3.10/dist-packages (from evaluate<0.4.0,>=0.2.2->autogluon.multimodal==0.7.0->autogluon) (2023.4.0)
    Collecting huggingface-hub>=0.7.0 (from evaluate<0.4.0,>=0.2.2->autogluon.multimodal==0.7.0->autogluon)
      Downloading huggingface_hub-0.14.1-py3-none-any.whl (224 kB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m224.5/224.5 kB[0m [31m214.8 MB/s[0m eta [36m0:00:00[0m
    [?25hCollecting responses<0.19 (from evaluate<0.4.0,>=0.2.2->autogluon.multimodal==0.7.0->autogluon)
      Downloading responses-0.18.0-py3-none-any.whl (38 kB)
    Requirement already satisfied: pip in /usr/local/lib/python3.10/dist-packages (from fastai<2.8,>=2.3.1->autogluon.tabular[all]==0.7.0->autogluon) (23.1.2)
    Requirement already satisfied: fastdownload<2,>=0.0.5 in /usr/local/lib/python3.10/dist-packages (from fastai<2.8,>=2.3.1->autogluon.tabular[all]==0.7.0->autogluon) (0.0.7)
    Requirement already satisfied: fastcore<1.6,>=1.5.29 in /usr/local/lib/python3.10/dist-packages (from fastai<2.8,>=2.3.1->autogluon.tabular[all]==0.7.0->autogluon) (1.5.29)
    Requirement already satisfied: fastprogress>=0.2.4 in /usr/local/lib/python3.10/dist-packages (from fastai<2.8,>=2.3.1->autogluon.tabular[all]==0.7.0->autogluon) (1.0.3)
    Requirement already satisfied: spacy<4 in /usr/local/lib/python3.10/dist-packages (from fastai<2.8,>=2.3.1->autogluon.tabular[all]==0.7.0->autogluon) (3.5.2)
    Requirement already satisfied: pydantic~=1.7 in /usr/local/lib/python3.10/dist-packages (from gluonts<0.13,>=0.12.0->autogluon.timeseries[all]==0.7.0->autogluon) (1.10.7)
    Requirement already satisfied: toolz~=0.10 in /usr/local/lib/python3.10/dist-packages (from gluonts<0.13,>=0.12.0->autogluon.timeseries[all]==0.7.0->autogluon) (0.12.0)
    Requirement already satisfied: typing-extensions~=4.0 in /usr/local/lib/python3.10/dist-packages (from gluonts<0.13,>=0.12.0->autogluon.timeseries[all]==0.7.0->autogluon) (4.5.0)
    Requirement already satisfied: future in /usr/local/lib/python3.10/dist-packages (from hyperopt<0.2.8,>=0.2.7->autogluon.core[all]==0.7.0->autogluon) (0.18.3)
    Requirement already satisfied: cloudpickle in /usr/local/lib/python3.10/dist-packages (from hyperopt<0.2.8,>=0.2.7->autogluon.core[all]==0.7.0->autogluon) (2.2.1)
    Requirement already satisfied: py4j in /usr/local/lib/python3.10/dist-packages (from hyperopt<0.2.8,>=0.2.7->autogluon.core[all]==0.7.0->autogluon) (0.10.9.7)
    Requirement already satisfied: MarkupSafe>=2.0 in /usr/local/lib/python3.10/dist-packages (from jinja2<3.2,>=3.0.3->autogluon.multimodal==0.7.0->autogluon) (2.1.2)
    Requirement already satisfied: attrs>=17.4.0 in /usr/local/lib/python3.10/dist-packages (from jsonschema<4.18,>=4.14->autogluon.multimodal==0.7.0->autogluon) (23.1.0)
    Requirement already satisfied: pyrsistent!=0.17.0,!=0.17.1,!=0.17.2,>=0.14.0 in /usr/local/lib/python3.10/dist-packages (from jsonschema<4.18,>=4.14->autogluon.multimodal==0.7.0->autogluon) (0.19.3)
    Requirement already satisfied: wheel in /usr/local/lib/python3.10/dist-packages (from lightgbm<3.4,>=3.3->autogluon.tabular[all]==0.7.0->autogluon) (0.40.0)
    Requirement already satisfied: gdown>=4.0.0 in /usr/local/lib/python3.10/dist-packages (from nlpaug<1.2.0,>=1.1.10->autogluon.multimodal==0.7.0->autogluon) (4.6.6)
    Requirement already satisfied: click in /usr/local/lib/python3.10/dist-packages (from nltk<4.0.0,>=3.4.5->autogluon.multimodal==0.7.0->autogluon) (8.1.3)
    Requirement already satisfied: regex>=2021.8.3 in /usr/local/lib/python3.10/dist-packages (from nltk<4.0.0,>=3.4.5->autogluon.multimodal==0.7.0->autogluon) (2022.10.31)
    Collecting antlr4-python3-runtime==4.9.* (from omegaconf<2.3.0,>=2.1.1->autogluon.multimodal==0.7.0->autogluon)
      Downloading antlr4-python3-runtime-4.9.3.tar.gz (117 kB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m117.0/117.0 kB[0m [31m186.4 MB/s[0m eta [36m0:00:00[0m
    [?25h  Preparing metadata (setup.py) ... [?25l[?25hdone
    Collecting colorama (from openmim<0.4.0,>0.1.5->autogluon.multimodal==0.7.0->autogluon)
      Downloading colorama-0.4.6-py2.py3-none-any.whl (25 kB)
    Collecting model-index (from openmim<0.4.0,>0.1.5->autogluon.multimodal==0.7.0->autogluon)
      Downloading model_index-0.1.11-py3-none-any.whl (34 kB)
    Requirement already satisfied: rich in /usr/local/lib/python3.10/dist-packages (from openmim<0.4.0,>0.1.5->autogluon.multimodal==0.7.0->autogluon) (13.3.4)
    Requirement already satisfied: tabulate in /usr/local/lib/python3.10/dist-packages (from openmim<0.4.0,>0.1.5->autogluon.multimodal==0.7.0->autogluon) (0.8.10)
    Requirement already satisfied: python-dateutil>=2.8.1 in /usr/local/lib/python3.10/dist-packages (from pandas<1.6,>=1.4.1->autogluon.core[all]==0.7.0->autogluon) (2.8.2)
    Requirement already satisfied: pytz>=2020.1 in /usr/local/lib/python3.10/dist-packages (from pandas<1.6,>=1.4.1->autogluon.core[all]==0.7.0->autogluon) (2022.7.1)
    Requirement already satisfied: Cython!=0.29.18,>=0.29 in /usr/local/lib/python3.10/dist-packages (from pmdarima<1.9,>=1.8.2->autogluon.timeseries[all]==0.7.0->autogluon) (0.29.34)
    Requirement already satisfied: urllib3 in /usr/local/lib/python3.10/dist-packages (from pmdarima<1.9,>=1.8.2->autogluon.timeseries[all]==0.7.0->autogluon) (1.26.15)
    Collecting lightning-utilities>=0.6.0.post0 (from pytorch-lightning<1.10.0,>=1.9.0->autogluon.multimodal==0.7.0->autogluon)
      Downloading lightning_utilities-0.8.0-py3-none-any.whl (20 kB)
    Requirement already satisfied: filelock in /usr/local/lib/python3.10/dist-packages (from ray[tune]<2.3,>=2.2->autogluon.core[all]==0.7.0->autogluon) (3.12.0)
    Requirement already satisfied: msgpack<2.0.0,>=1.0.0 in /usr/local/lib/python3.10/dist-packages (from ray[tune]<2.3,>=2.2->autogluon.core[all]==0.7.0->autogluon) (1.0.5)
    Requirement already satisfied: protobuf!=3.19.5,>=3.15.3 in /usr/local/lib/python3.10/dist-packages (from ray[tune]<2.3,>=2.2->autogluon.core[all]==0.7.0->autogluon) (3.20.3)
    Collecting aiosignal (from ray[tune]<2.3,>=2.2->autogluon.core[all]==0.7.0->autogluon)
      Downloading aiosignal-1.3.1-py3-none-any.whl (7.6 kB)
    Collecting frozenlist (from ray[tune]<2.3,>=2.2->autogluon.core[all]==0.7.0->autogluon)
      Downloading frozenlist-1.3.3-cp310-cp310-manylinux_2_5_x86_64.manylinux1_x86_64.manylinux_2_17_x86_64.manylinux2014_x86_64.whl (149 kB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m149.6/149.6 kB[0m [31m143.4 MB/s[0m eta [36m0:00:00[0m
    [?25hCollecting virtualenv>=20.0.24 (from ray[tune]<2.3,>=2.2->autogluon.core[all]==0.7.0->autogluon)
      Downloading virtualenv-20.23.0-py3-none-any.whl (3.3 MB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m3.3/3.3 MB[0m [31m189.6 MB/s[0m eta [36m0:00:00[0m
    [?25hRequirement already satisfied: grpcio>=1.42.0 in /usr/local/lib/python3.10/dist-packages (from ray[tune]<2.3,>=2.2->autogluon.core[all]==0.7.0->autogluon) (1.54.0)
    Collecting tensorboardX>=1.9 (from ray[tune]<2.3,>=2.2->autogluon.core[all]==0.7.0->autogluon)
      Downloading tensorboardX-2.6-py2.py3-none-any.whl (114 kB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m114.5/114.5 kB[0m [31m183.4 MB/s[0m eta [36m0:00:00[0m
    [?25hRequirement already satisfied: certifi>=2017.4.17 in /usr/local/lib/python3.10/dist-packages (from requests->autogluon.core[all]==0.7.0->autogluon) (2022.12.7)
    Requirement already satisfied: charset-normalizer~=2.0.0 in /usr/local/lib/python3.10/dist-packages (from requests->autogluon.core[all]==0.7.0->autogluon) (2.0.12)
    Requirement already satisfied: idna<4,>=2.5 in /usr/local/lib/python3.10/dist-packages (from requests->autogluon.core[all]==0.7.0->autogluon) (3.4)
    Requirement already satisfied: imageio>=2.4.1 in /usr/local/lib/python3.10/dist-packages (from scikit-image<0.20.0,>=0.19.1->autogluon.multimodal==0.7.0->autogluon) (2.25.1)
    Requirement already satisfied: tifffile>=2019.7.26 in /usr/local/lib/python3.10/dist-packages (from scikit-image<0.20.0,>=0.19.1->autogluon.multimodal==0.7.0->autogluon) (2023.4.12)
    Requirement already satisfied: PyWavelets>=1.1.1 in /usr/local/lib/python3.10/dist-packages (from scikit-image<0.20.0,>=0.19.1->autogluon.multimodal==0.7.0->autogluon) (1.4.1)
    Requirement already satisfied: threadpoolctl>=2.0.0 in /usr/local/lib/python3.10/dist-packages (from scikit-learn<1.3,>=1.0->autogluon.core[all]==0.7.0->autogluon) (3.1.0)
    Collecting deprecated>=1.2.13 (from sktime<0.16,>=0.14->autogluon.timeseries[all]==0.7.0->autogluon)
      Downloading Deprecated-1.2.13-py2.py3-none-any.whl (9.6 kB)
    Requirement already satisfied: numba>=0.55 in /usr/local/lib/python3.10/dist-packages (from sktime<0.16,>=0.14->autogluon.timeseries[all]==0.7.0->autogluon) (0.56.4)
    Requirement already satisfied: patsy>=0.5.2 in /usr/local/lib/python3.10/dist-packages (from statsmodels<0.14,>=0.13.0->autogluon.timeseries[all]==0.7.0->autogluon) (0.5.3)
    Requirement already satisfied: absl-py>=0.4 in /usr/local/lib/python3.10/dist-packages (from tensorboard<3,>=2.9->autogluon.multimodal==0.7.0->autogluon) (1.4.0)
    Requirement already satisfied: google-auth<3,>=1.6.3 in /usr/local/lib/python3.10/dist-packages (from tensorboard<3,>=2.9->autogluon.multimodal==0.7.0->autogluon) (2.17.3)
    Requirement already satisfied: google-auth-oauthlib<1.1,>=0.5 in /usr/local/lib/python3.10/dist-packages (from tensorboard<3,>=2.9->autogluon.multimodal==0.7.0->autogluon) (1.0.0)
    Requirement already satisfied: markdown>=2.6.8 in /usr/local/lib/python3.10/dist-packages (from tensorboard<3,>=2.9->autogluon.multimodal==0.7.0->autogluon) (3.4.3)
    Requirement already satisfied: tensorboard-data-server<0.8.0,>=0.7.0 in /usr/local/lib/python3.10/dist-packages (from tensorboard<3,>=2.9->autogluon.multimodal==0.7.0->autogluon) (0.7.0)
    Requirement already satisfied: tensorboard-plugin-wit>=1.6.0 in /usr/local/lib/python3.10/dist-packages (from tensorboard<3,>=2.9->autogluon.multimodal==0.7.0->autogluon) (1.8.1)
    Requirement already satisfied: werkzeug>=1.0.1 in /usr/local/lib/python3.10/dist-packages (from tensorboard<3,>=2.9->autogluon.multimodal==0.7.0->autogluon) (2.3.0)
    Collecting nvidia-cuda-runtime-cu11==11.7.99 (from torch<1.14,>=1.9->autogluon.multimodal==0.7.0->autogluon)
      Downloading nvidia_cuda_runtime_cu11-11.7.99-py3-none-manylinux1_x86_64.whl (849 kB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m849.3/849.3 kB[0m [31m222.4 MB/s[0m eta [36m0:00:00[0m
    [?25hCollecting nvidia-cudnn-cu11==8.5.0.96 (from torch<1.14,>=1.9->autogluon.multimodal==0.7.0->autogluon)
      Downloading nvidia_cudnn_cu11-8.5.0.96-2-py3-none-manylinux1_x86_64.whl (557.1 MB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m557.1/557.1 MB[0m [31m214.8 MB/s[0m eta [36m0:00:00[0m
    [?25hCollecting nvidia-cublas-cu11==11.10.3.66 (from torch<1.14,>=1.9->autogluon.multimodal==0.7.0->autogluon)
      Downloading nvidia_cublas_cu11-11.10.3.66-py3-none-manylinux1_x86_64.whl (317.1 MB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m317.1/317.1 MB[0m [31m150.5 MB/s[0m eta [36m0:00:00[0m
    [?25hCollecting nvidia-cuda-nvrtc-cu11==11.7.99 (from torch<1.14,>=1.9->autogluon.multimodal==0.7.0->autogluon)
      Downloading nvidia_cuda_nvrtc_cu11-11.7.99-2-py3-none-manylinux1_x86_64.whl (21.0 MB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m21.0/21.0 MB[0m [31m207.6 MB/s[0m eta [36m0:00:00[0m
    [?25hCollecting pyDeprecate==0.3.* (from torchmetrics<0.9.0,>=0.8.0->autogluon.multimodal==0.7.0->autogluon)
      Downloading pyDeprecate-0.3.2-py3-none-any.whl (10 kB)
    Collecting tokenizers!=0.11.3,<0.14,>=0.11.1 (from transformers<4.27.0,>=4.23.0->autogluon.multimodal==0.7.0->autogluon)
      Downloading tokenizers-0.13.3-cp310-cp310-manylinux_2_17_x86_64.manylinux2014_x86_64.whl (7.8 MB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m7.8/7.8 MB[0m [31m207.9 MB/s[0m eta [36m0:00:00[0m
    [?25hRequirement already satisfied: contourpy>=1.0.1 in /usr/local/lib/python3.10/dist-packages (from matplotlib->autogluon.core[all]==0.7.0->autogluon) (1.0.7)
    Requirement already satisfied: cycler>=0.10 in /usr/local/lib/python3.10/dist-packages (from matplotlib->autogluon.core[all]==0.7.0->autogluon) (0.11.0)
    Requirement already satisfied: fonttools>=4.22.0 in /usr/local/lib/python3.10/dist-packages (from matplotlib->autogluon.core[all]==0.7.0->autogluon) (4.39.3)
    Requirement already satisfied: kiwisolver>=1.0.1 in /usr/local/lib/python3.10/dist-packages (from matplotlib->autogluon.core[all]==0.7.0->autogluon) (1.4.4)
    Requirement already satisfied: pyparsing>=2.3.1 in /usr/local/lib/python3.10/dist-packages (from matplotlib->autogluon.core[all]==0.7.0->autogluon) (3.0.9)
    Requirement already satisfied: pyarrow>=8.0.0 in /usr/local/lib/python3.10/dist-packages (from datasets>=2.0.0->evaluate<0.4.0,>=0.2.2->autogluon.multimodal==0.7.0->autogluon) (9.0.0)
    Collecting aiohttp (from datasets>=2.0.0->evaluate<0.4.0,>=0.2.2->autogluon.multimodal==0.7.0->autogluon)
      Downloading aiohttp-3.8.4-cp310-cp310-manylinux_2_17_x86_64.manylinux2014_x86_64.whl (1.0 MB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m1.0/1.0 MB[0m [31m186.0 MB/s[0m eta [36m0:00:00[0m
    [?25hRequirement already satisfied: wrapt<2,>=1.10 in /usr/local/lib/python3.10/dist-packages (from deprecated>=1.2.13->sktime<0.16,>=0.14->autogluon.timeseries[all]==0.7.0->autogluon) (1.14.1)
    Requirement already satisfied: beautifulsoup4 in /usr/local/lib/python3.10/dist-packages (from gdown>=4.0.0->nlpaug<1.2.0,>=1.1.10->autogluon.multimodal==0.7.0->autogluon) (4.11.2)
    Requirement already satisfied: cachetools<6.0,>=2.0.0 in /usr/local/lib/python3.10/dist-packages (from google-auth<3,>=1.6.3->tensorboard<3,>=2.9->autogluon.multimodal==0.7.0->autogluon) (5.3.0)
    Requirement already satisfied: pyasn1-modules>=0.2.1 in /usr/local/lib/python3.10/dist-packages (from google-auth<3,>=1.6.3->tensorboard<3,>=2.9->autogluon.multimodal==0.7.0->autogluon) (0.3.0)
    Requirement already satisfied: rsa<5,>=3.1.4 in /usr/local/lib/python3.10/dist-packages (from google-auth<3,>=1.6.3->tensorboard<3,>=2.9->autogluon.multimodal==0.7.0->autogluon) (4.9)
    Requirement already satisfied: requests-oauthlib>=0.7.0 in /usr/local/lib/python3.10/dist-packages (from google-auth-oauthlib<1.1,>=0.5->tensorboard<3,>=2.9->autogluon.multimodal==0.7.0->autogluon) (1.3.1)
    Requirement already satisfied: llvmlite<0.40,>=0.39.0dev0 in /usr/local/lib/python3.10/dist-packages (from numba>=0.55->sktime<0.16,>=0.14->autogluon.timeseries[all]==0.7.0->autogluon) (0.39.1)
    Requirement already satisfied: spacy-legacy<3.1.0,>=3.0.11 in /usr/local/lib/python3.10/dist-packages (from spacy<4->fastai<2.8,>=2.3.1->autogluon.tabular[all]==0.7.0->autogluon) (3.0.12)
    Requirement already satisfied: spacy-loggers<2.0.0,>=1.0.0 in /usr/local/lib/python3.10/dist-packages (from spacy<4->fastai<2.8,>=2.3.1->autogluon.tabular[all]==0.7.0->autogluon) (1.0.4)
    Requirement already satisfied: murmurhash<1.1.0,>=0.28.0 in /usr/local/lib/python3.10/dist-packages (from spacy<4->fastai<2.8,>=2.3.1->autogluon.tabular[all]==0.7.0->autogluon) (1.0.9)
    Requirement already satisfied: cymem<2.1.0,>=2.0.2 in /usr/local/lib/python3.10/dist-packages (from spacy<4->fastai<2.8,>=2.3.1->autogluon.tabular[all]==0.7.0->autogluon) (2.0.7)
    Requirement already satisfied: preshed<3.1.0,>=3.0.2 in /usr/local/lib/python3.10/dist-packages (from spacy<4->fastai<2.8,>=2.3.1->autogluon.tabular[all]==0.7.0->autogluon) (3.0.8)
    Requirement already satisfied: thinc<8.2.0,>=8.1.8 in /usr/local/lib/python3.10/dist-packages (from spacy<4->fastai<2.8,>=2.3.1->autogluon.tabular[all]==0.7.0->autogluon) (8.1.9)
    Requirement already satisfied: wasabi<1.2.0,>=0.9.1 in /usr/local/lib/python3.10/dist-packages (from spacy<4->fastai<2.8,>=2.3.1->autogluon.tabular[all]==0.7.0->autogluon) (1.1.1)
    Requirement already satisfied: srsly<3.0.0,>=2.4.3 in /usr/local/lib/python3.10/dist-packages (from spacy<4->fastai<2.8,>=2.3.1->autogluon.tabular[all]==0.7.0->autogluon) (2.4.6)
    Requirement already satisfied: catalogue<2.1.0,>=2.0.6 in /usr/local/lib/python3.10/dist-packages (from spacy<4->fastai<2.8,>=2.3.1->autogluon.tabular[all]==0.7.0->autogluon) (2.0.8)
    Requirement already satisfied: typer<0.8.0,>=0.3.0 in /usr/local/lib/python3.10/dist-packages (from spacy<4->fastai<2.8,>=2.3.1->autogluon.tabular[all]==0.7.0->autogluon) (0.7.0)
    Requirement already satisfied: pathy>=0.10.0 in /usr/local/lib/python3.10/dist-packages (from spacy<4->fastai<2.8,>=2.3.1->autogluon.tabular[all]==0.7.0->autogluon) (0.10.1)
    Requirement already satisfied: smart-open<7.0.0,>=5.2.1 in /usr/local/lib/python3.10/dist-packages (from spacy<4->fastai<2.8,>=2.3.1->autogluon.tabular[all]==0.7.0->autogluon) (6.3.0)
    Requirement already satisfied: langcodes<4.0.0,>=3.2.0 in /usr/local/lib/python3.10/dist-packages (from spacy<4->fastai<2.8,>=2.3.1->autogluon.tabular[all]==0.7.0->autogluon) (3.3.0)
    Collecting distlib<1,>=0.3.6 (from virtualenv>=20.0.24->ray[tune]<2.3,>=2.2->autogluon.core[all]==0.7.0->autogluon)
      Downloading distlib-0.3.6-py2.py3-none-any.whl (468 kB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m468.5/468.5 kB[0m [31m181.1 MB/s[0m eta [36m0:00:00[0m
    [?25hRequirement already satisfied: platformdirs<4,>=3.2 in /usr/local/lib/python3.10/dist-packages (from virtualenv>=20.0.24->ray[tune]<2.3,>=2.2->autogluon.core[all]==0.7.0->autogluon) (3.3.0)
    Collecting ordered-set (from model-index->openmim<0.4.0,>0.1.5->autogluon.multimodal==0.7.0->autogluon)
      Downloading ordered_set-4.1.0-py3-none-any.whl (7.6 kB)
    Requirement already satisfied: tenacity>=6.2.0 in /usr/local/lib/python3.10/dist-packages (from plotly->catboost<1.2,>=1.0->autogluon.tabular[all]==0.7.0->autogluon) (8.2.2)
    Requirement already satisfied: markdown-it-py<3.0.0,>=2.2.0 in /usr/local/lib/python3.10/dist-packages (from rich->openmim<0.4.0,>0.1.5->autogluon.multimodal==0.7.0->autogluon) (2.2.0)
    Requirement already satisfied: pygments<3.0.0,>=2.13.0 in /usr/local/lib/python3.10/dist-packages (from rich->openmim<0.4.0,>0.1.5->autogluon.multimodal==0.7.0->autogluon) (2.14.0)
    Collecting multidict<7.0,>=4.5 (from aiohttp->datasets>=2.0.0->evaluate<0.4.0,>=0.2.2->autogluon.multimodal==0.7.0->autogluon)
      Downloading multidict-6.0.4-cp310-cp310-manylinux_2_17_x86_64.manylinux2014_x86_64.whl (114 kB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m114.5/114.5 kB[0m [31m242.1 MB/s[0m eta [36m0:00:00[0m
    [?25hCollecting async-timeout<5.0,>=4.0.0a3 (from aiohttp->datasets>=2.0.0->evaluate<0.4.0,>=0.2.2->autogluon.multimodal==0.7.0->autogluon)
      Downloading async_timeout-4.0.2-py3-none-any.whl (5.8 kB)
    Collecting yarl<2.0,>=1.0 (from aiohttp->datasets>=2.0.0->evaluate<0.4.0,>=0.2.2->autogluon.multimodal==0.7.0->autogluon)
      Downloading yarl-1.9.2-cp310-cp310-manylinux_2_17_x86_64.manylinux2014_x86_64.whl (268 kB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m268.8/268.8 kB[0m [31m287.4 MB/s[0m eta [36m0:00:00[0m
    [?25hRequirement already satisfied: mdurl~=0.1 in /usr/local/lib/python3.10/dist-packages (from markdown-it-py<3.0.0,>=2.2.0->rich->openmim<0.4.0,>0.1.5->autogluon.multimodal==0.7.0->autogluon) (0.1.2)
    Requirement already satisfied: pyasn1<0.6.0,>=0.4.6 in /usr/local/lib/python3.10/dist-packages (from pyasn1-modules>=0.2.1->google-auth<3,>=1.6.3->tensorboard<3,>=2.9->autogluon.multimodal==0.7.0->autogluon) (0.5.0)
    Requirement already satisfied: oauthlib>=3.0.0 in /usr/local/lib/python3.10/dist-packages (from requests-oauthlib>=0.7.0->google-auth-oauthlib<1.1,>=0.5->tensorboard<3,>=2.9->autogluon.multimodal==0.7.0->autogluon) (3.2.2)
    Requirement already satisfied: blis<0.8.0,>=0.7.8 in /usr/local/lib/python3.10/dist-packages (from thinc<8.2.0,>=8.1.8->spacy<4->fastai<2.8,>=2.3.1->autogluon.tabular[all]==0.7.0->autogluon) (0.7.9)
    Requirement already satisfied: confection<1.0.0,>=0.0.1 in /usr/local/lib/python3.10/dist-packages (from thinc<8.2.0,>=8.1.8->spacy<4->fastai<2.8,>=2.3.1->autogluon.tabular[all]==0.7.0->autogluon) (0.0.4)
    Requirement already satisfied: soupsieve>1.2 in /usr/local/lib/python3.10/dist-packages (from beautifulsoup4->gdown>=4.0.0->nlpaug<1.2.0,>=1.1.10->autogluon.multimodal==0.7.0->autogluon) (2.4.1)
    Requirement already satisfied: PySocks!=1.5.7,>=1.5.6 in /usr/local/lib/python3.10/dist-packages (from requests->autogluon.core[all]==0.7.0->autogluon) (1.7.1)
    Building wheels for collected packages: fairscale, antlr4-python3-runtime, seqeval
      Building wheel for fairscale (pyproject.toml) ... [?25l[?25hdone
      Created wheel for fairscale: filename=fairscale-0.4.13-py3-none-any.whl size=332112 sha256=9747ee3c74fc54c9aa0e2d05e073b3b188704543563518352d7fc605e94065e4
      Stored in directory: /tmp/pip-ephem-wheel-cache-pwpyr41z/wheels/78/a4/c0/fb0a7ef03cff161611c3fa40c6cf898f76e58ec421b88e8cb3
      Building wheel for antlr4-python3-runtime (setup.py) ... [?25l[?25hdone
      Created wheel for antlr4-python3-runtime: filename=antlr4_python3_runtime-4.9.3-py3-none-any.whl size=144554 sha256=071f4556a7de653f82beb0cc0dad361b02e0921780e445afd0439db800bd12bb
      Stored in directory: /tmp/pip-ephem-wheel-cache-pwpyr41z/wheels/12/93/dd/1f6a127edc45659556564c5730f6d4e300888f4bca2d4c5a88
      Building wheel for seqeval (setup.py) ... [?25l[?25hdone
      Created wheel for seqeval: filename=seqeval-1.2.2-py3-none-any.whl size=16165 sha256=1a552eea83f30377ff20ab49274eb988607aabc3fa5ff11c81aa4e98a6e69c67
      Stored in directory: /tmp/pip-ephem-wheel-cache-pwpyr41z/wheels/1a/67/4a/ad4082dd7dfc30f2abfe4d80a2ed5926a506eb8a972b4767fa
    Successfully built fairscale antlr4-python3-runtime seqeval
    Installing collected packages: tokenizers, sentencepiece, distlib, antlr4-python3-runtime, xxhash, virtualenv, ujson, tensorboardX, pyDeprecate, Pillow, ordered-set, omegaconf, nvidia-cuda-runtime-cu11, nvidia-cuda-nvrtc-cu11, nvidia-cublas-cu11, nptyping, networkx, multidict, lightning-utilities, jsonschema, jmespath, frozenlist, dill, deprecated, colorama, async-timeout, yarl, responses, pytesseract, nvidia-cudnn-cu11, multiprocess, model-index, huggingface-hub, botocore, aiosignal, transformers, torch, seqeval, s3transfer, ray, openmim, gluonts, catboost, aiohttp, torchvision, torchmetrics, statsforecast, sktime, pytorch-metric-learning, pmdarima, nlpaug, fairscale, boto3, accelerate, timm, tbats, pytorch-lightning, datasets, autogluon.common, evaluate, autogluon.features, autogluon.core, autogluon.tabular, autogluon.multimodal, autogluon.timeseries, autogluon
      Attempting uninstall: Pillow
        Found existing installation: Pillow 8.4.0
        Uninstalling Pillow-8.4.0:
          Successfully uninstalled Pillow-8.4.0
      Attempting uninstall: networkx
        Found existing installation: networkx 3.1
        Uninstalling networkx-3.1:
          Successfully uninstalled networkx-3.1
      Attempting uninstall: jsonschema
        Found existing installation: jsonschema 4.3.3
        Uninstalling jsonschema-4.3.3:
          Successfully uninstalled jsonschema-4.3.3
      Attempting uninstall: torch
        Found existing installation: torch 2.0.1+cu118
        Uninstalling torch-2.0.1+cu118:
          Successfully uninstalled torch-2.0.1+cu118
      Attempting uninstall: torchvision
        Found existing installation: torchvision 0.15.2+cu118
        Uninstalling torchvision-0.15.2+cu118:
          Successfully uninstalled torchvision-0.15.2+cu118
    [31mERROR: pip's dependency resolver does not currently take into account all the packages that are installed. This behaviour is the source of the following dependency conflicts.
    panel 0.14.4 requires bokeh<2.5.0,>=2.4.0, but you have bokeh 2.0.1 which is incompatible.
    torchaudio 2.0.2+cu118 requires torch==2.0.1, but you have torch 1.13.1 which is incompatible.
    torchdata 0.6.1 requires torch==2.0.1, but you have torch 1.13.1 which is incompatible.
    torchtext 0.15.2 requires torch==2.0.1, but you have torch 1.13.1 which is incompatible.[0m[31m
    [0mSuccessfully installed Pillow-9.5.0 accelerate-0.16.0 aiohttp-3.8.4 aiosignal-1.3.1 antlr4-python3-runtime-4.9.3 async-timeout-4.0.2 autogluon-0.7.0 autogluon.common-0.7.0 autogluon.core-0.7.0 autogluon.features-0.7.0 autogluon.multimodal-0.7.0 autogluon.tabular-0.7.0 autogluon.timeseries-0.7.0 boto3-1.26.137 botocore-1.29.137 catboost-1.1.1 colorama-0.4.6 datasets-2.12.0 deprecated-1.2.13 dill-0.3.6 distlib-0.3.6 evaluate-0.3.0 fairscale-0.4.13 frozenlist-1.3.3 gluonts-0.12.8 huggingface-hub-0.14.1 jmespath-1.0.1 jsonschema-4.17.3 lightning-utilities-0.8.0 model-index-0.1.11 multidict-6.0.4 multiprocess-0.70.14 networkx-2.8.8 nlpaug-1.1.11 nptyping-2.4.1 nvidia-cublas-cu11-11.10.3.66 nvidia-cuda-nvrtc-cu11-11.7.99 nvidia-cuda-runtime-cu11-11.7.99 nvidia-cudnn-cu11-8.5.0.96 omegaconf-2.2.3 openmim-0.3.7 ordered-set-4.1.0 pmdarima-1.8.5 pyDeprecate-0.3.2 pytesseract-0.3.10 pytorch-lightning-1.9.5 pytorch-metric-learning-1.7.3 ray-2.2.0 responses-0.18.0 s3transfer-0.6.1 sentencepiece-0.1.99 seqeval-1.2.2 sktime-0.15.1 statsforecast-1.4.0 tbats-1.1.3 tensorboardX-2.6 timm-0.6.13 tokenizers-0.13.3 torch-1.13.1 torchmetrics-0.8.2 torchvision-0.14.1 transformers-4.26.1 ujson-5.7.0 virtualenv-20.23.0 xxhash-3.2.0 yarl-1.9.2




### Setup Kaggle API Key

Note: I applied these steps directly in my local terminal (only to setup kaggle cli) then I used the kaggle cli from inside the notebook for the rest of the project


```python
# create the .kaggle directory and an empty kaggle.json file
!mkdir -p /root/.kaggle
!touch /root/.kaggle/kaggle.json
!chmod 600 /root/.kaggle/kaggle.json
```


```python
# Fill in your user name and key from creating the kaggle account and API token file
import json
kaggle_username = "surajparui"
kaggle_key = "84f379844a3cffa6aa42566b0880ae5b"

# Save API token the kaggle.json file
with open("/root/.kaggle/kaggle.json", "w") as f:
    f.write(json.dumps({"username": kaggle_username, "key": kaggle_key}))
```

### Download and explore dataset

### Go to the bike sharing demand competition and agree to the terms
![kaggle6.png](attachment:kaggle6.png)


```python
# Download the dataset, it will be in a .zip file so you'll need to unzip it as well.
!kaggle competitions download -c bike-sharing-demand
# If you already downloaded it you can use the -o command to overwrite the file
!unzip -o bike-sharing-demand.zip
```

    bike-sharing-demand.zip: Skipping, found more recently modified local copy (use --force to force download)
    Archive:  bike-sharing-demand.zip
      inflating: sampleSubmission.csv    
      inflating: test.csv                
      inflating: train.csv               



```python
import pandas as pd
from autogluon.tabular import TabularPredictor
```


```python
# Create the train dataset in pandas by reading the csv
# Set the parsing of the datetime column so you can use some of the `dt` features in pandas later
train = pd.read_csv('train.csv', parse_dates=['datetime'])
train.head()
```





  <div id="df-42182508-bdbd-462b-955f-e68176e41309">
    <div class="colab-df-container">
      <div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>datetime</th>
      <th>season</th>
      <th>holiday</th>
      <th>workingday</th>
      <th>weather</th>
      <th>temp</th>
      <th>atemp</th>
      <th>humidity</th>
      <th>windspeed</th>
      <th>casual</th>
      <th>registered</th>
      <th>count</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2011-01-01 00:00:00</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>9.84</td>
      <td>14.395</td>
      <td>81</td>
      <td>0.0</td>
      <td>3</td>
      <td>13</td>
      <td>16</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2011-01-01 01:00:00</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>9.02</td>
      <td>13.635</td>
      <td>80</td>
      <td>0.0</td>
      <td>8</td>
      <td>32</td>
      <td>40</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2011-01-01 02:00:00</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>9.02</td>
      <td>13.635</td>
      <td>80</td>
      <td>0.0</td>
      <td>5</td>
      <td>27</td>
      <td>32</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2011-01-01 03:00:00</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>9.84</td>
      <td>14.395</td>
      <td>75</td>
      <td>0.0</td>
      <td>3</td>
      <td>10</td>
      <td>13</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2011-01-01 04:00:00</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>9.84</td>
      <td>14.395</td>
      <td>75</td>
      <td>0.0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
    </tr>
  </tbody>
</table>
</div>
      <button class="colab-df-convert" onclick="convertToInteractive('df-42182508-bdbd-462b-955f-e68176e41309')"
              title="Convert this dataframe to an interactive table."
              style="display:none;">

  <svg xmlns="http://www.w3.org/2000/svg" height="24px"viewBox="0 0 24 24"
       width="24px">
    <path d="M0 0h24v24H0V0z" fill="none"/>
    <path d="M18.56 5.44l.94 2.06.94-2.06 2.06-.94-2.06-.94-.94-2.06-.94 2.06-2.06.94zm-11 1L8.5 8.5l.94-2.06 2.06-.94-2.06-.94L8.5 2.5l-.94 2.06-2.06.94zm10 10l.94 2.06.94-2.06 2.06-.94-2.06-.94-.94-2.06-.94 2.06-2.06.94z"/><path d="M17.41 7.96l-1.37-1.37c-.4-.4-.92-.59-1.43-.59-.52 0-1.04.2-1.43.59L10.3 9.45l-7.72 7.72c-.78.78-.78 2.05 0 2.83L4 21.41c.39.39.9.59 1.41.59.51 0 1.02-.2 1.41-.59l7.78-7.78 2.81-2.81c.8-.78.8-2.07 0-2.86zM5.41 20L4 18.59l7.72-7.72 1.47 1.35L5.41 20z"/>
  </svg>
      </button>

  <style>
    .colab-df-container {
      display:flex;
      flex-wrap:wrap;
      gap: 12px;
    }

    .colab-df-convert {
      background-color: #E8F0FE;
      border: none;
      border-radius: 50%;
      cursor: pointer;
      display: none;
      fill: #1967D2;
      height: 32px;
      padding: 0 0 0 0;
      width: 32px;
    }

    .colab-df-convert:hover {
      background-color: #E2EBFA;
      box-shadow: 0px 1px 2px rgba(60, 64, 67, 0.3), 0px 1px 3px 1px rgba(60, 64, 67, 0.15);
      fill: #174EA6;
    }

    [theme=dark] .colab-df-convert {
      background-color: #3B4455;
      fill: #D2E3FC;
    }

    [theme=dark] .colab-df-convert:hover {
      background-color: #434B5C;
      box-shadow: 0px 1px 3px 1px rgba(0, 0, 0, 0.15);
      filter: drop-shadow(0px 1px 2px rgba(0, 0, 0, 0.3));
      fill: #FFFFFF;
    }
  </style>

      <script>
        const buttonEl =
          document.querySelector('#df-42182508-bdbd-462b-955f-e68176e41309 button.colab-df-convert');
        buttonEl.style.display =
          google.colab.kernel.accessAllowed ? 'block' : 'none';

        async function convertToInteractive(key) {
          const element = document.querySelector('#df-42182508-bdbd-462b-955f-e68176e41309');
          const dataTable =
            await google.colab.kernel.invokeFunction('convertToInteractive',
                                                     [key], {});
          if (!dataTable) return;

          const docLinkHtml = 'Like what you see? Visit the ' +
            '<a target="_blank" href=https://colab.research.google.com/notebooks/data_table.ipynb>data table notebook</a>'
            + ' to learn more about interactive tables.';
          element.innerHTML = '';
          dataTable['output_type'] = 'display_data';
          await google.colab.output.renderOutput(dataTable, element);
          const docLink = document.createElement('div');
          docLink.innerHTML = docLinkHtml;
          element.appendChild(docLink);
        }
      </script>
    </div>
  </div>





```python
train.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 10886 entries, 0 to 10885
    Data columns (total 12 columns):
     #   Column      Non-Null Count  Dtype         
    ---  ------      --------------  -----         
     0   datetime    10886 non-null  datetime64[ns]
     1   season      10886 non-null  int64         
     2   holiday     10886 non-null  int64         
     3   workingday  10886 non-null  int64         
     4   weather     10886 non-null  int64         
     5   temp        10886 non-null  float64       
     6   atemp       10886 non-null  float64       
     7   humidity    10886 non-null  int64         
     8   windspeed   10886 non-null  float64       
     9   casual      10886 non-null  int64         
     10  registered  10886 non-null  int64         
     11  count       10886 non-null  int64         
    dtypes: datetime64[ns](1), float64(3), int64(8)
    memory usage: 1020.7 KB



```python
# Simple output of the train dataset to view some of the min/max/varition of the dataset features.
train.describe()
```





  <div id="df-2a8ac683-60e0-43dd-8818-f09f9f5c749a">
    <div class="colab-df-container">
      <div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>season</th>
      <th>holiday</th>
      <th>workingday</th>
      <th>weather</th>
      <th>temp</th>
      <th>atemp</th>
      <th>humidity</th>
      <th>windspeed</th>
      <th>casual</th>
      <th>registered</th>
      <th>count</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>10886.000000</td>
      <td>10886.000000</td>
      <td>10886.000000</td>
      <td>10886.000000</td>
      <td>10886.00000</td>
      <td>10886.000000</td>
      <td>10886.000000</td>
      <td>10886.000000</td>
      <td>10886.000000</td>
      <td>10886.000000</td>
      <td>10886.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>2.506614</td>
      <td>0.028569</td>
      <td>0.680875</td>
      <td>1.418427</td>
      <td>20.23086</td>
      <td>23.655084</td>
      <td>61.886460</td>
      <td>12.799395</td>
      <td>36.021955</td>
      <td>155.552177</td>
      <td>191.574132</td>
    </tr>
    <tr>
      <th>std</th>
      <td>1.116174</td>
      <td>0.166599</td>
      <td>0.466159</td>
      <td>0.633839</td>
      <td>7.79159</td>
      <td>8.474601</td>
      <td>19.245033</td>
      <td>8.164537</td>
      <td>49.960477</td>
      <td>151.039033</td>
      <td>181.144454</td>
    </tr>
    <tr>
      <th>min</th>
      <td>1.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>1.000000</td>
      <td>0.82000</td>
      <td>0.760000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>1.000000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>2.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>1.000000</td>
      <td>13.94000</td>
      <td>16.665000</td>
      <td>47.000000</td>
      <td>7.001500</td>
      <td>4.000000</td>
      <td>36.000000</td>
      <td>42.000000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>3.000000</td>
      <td>0.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>20.50000</td>
      <td>24.240000</td>
      <td>62.000000</td>
      <td>12.998000</td>
      <td>17.000000</td>
      <td>118.000000</td>
      <td>145.000000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>4.000000</td>
      <td>0.000000</td>
      <td>1.000000</td>
      <td>2.000000</td>
      <td>26.24000</td>
      <td>31.060000</td>
      <td>77.000000</td>
      <td>16.997900</td>
      <td>49.000000</td>
      <td>222.000000</td>
      <td>284.000000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>4.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>4.000000</td>
      <td>41.00000</td>
      <td>45.455000</td>
      <td>100.000000</td>
      <td>56.996900</td>
      <td>367.000000</td>
      <td>886.000000</td>
      <td>977.000000</td>
    </tr>
  </tbody>
</table>
</div>
      <button class="colab-df-convert" onclick="convertToInteractive('df-2a8ac683-60e0-43dd-8818-f09f9f5c749a')"
              title="Convert this dataframe to an interactive table."
              style="display:none;">

  <svg xmlns="http://www.w3.org/2000/svg" height="24px"viewBox="0 0 24 24"
       width="24px">
    <path d="M0 0h24v24H0V0z" fill="none"/>
    <path d="M18.56 5.44l.94 2.06.94-2.06 2.06-.94-2.06-.94-.94-2.06-.94 2.06-2.06.94zm-11 1L8.5 8.5l.94-2.06 2.06-.94-2.06-.94L8.5 2.5l-.94 2.06-2.06.94zm10 10l.94 2.06.94-2.06 2.06-.94-2.06-.94-.94-2.06-.94 2.06-2.06.94z"/><path d="M17.41 7.96l-1.37-1.37c-.4-.4-.92-.59-1.43-.59-.52 0-1.04.2-1.43.59L10.3 9.45l-7.72 7.72c-.78.78-.78 2.05 0 2.83L4 21.41c.39.39.9.59 1.41.59.51 0 1.02-.2 1.41-.59l7.78-7.78 2.81-2.81c.8-.78.8-2.07 0-2.86zM5.41 20L4 18.59l7.72-7.72 1.47 1.35L5.41 20z"/>
  </svg>
      </button>

  <style>
    .colab-df-container {
      display:flex;
      flex-wrap:wrap;
      gap: 12px;
    }

    .colab-df-convert {
      background-color: #E8F0FE;
      border: none;
      border-radius: 50%;
      cursor: pointer;
      display: none;
      fill: #1967D2;
      height: 32px;
      padding: 0 0 0 0;
      width: 32px;
    }

    .colab-df-convert:hover {
      background-color: #E2EBFA;
      box-shadow: 0px 1px 2px rgba(60, 64, 67, 0.3), 0px 1px 3px 1px rgba(60, 64, 67, 0.15);
      fill: #174EA6;
    }

    [theme=dark] .colab-df-convert {
      background-color: #3B4455;
      fill: #D2E3FC;
    }

    [theme=dark] .colab-df-convert:hover {
      background-color: #434B5C;
      box-shadow: 0px 1px 3px 1px rgba(0, 0, 0, 0.15);
      filter: drop-shadow(0px 1px 2px rgba(0, 0, 0, 0.3));
      fill: #FFFFFF;
    }
  </style>

      <script>
        const buttonEl =
          document.querySelector('#df-2a8ac683-60e0-43dd-8818-f09f9f5c749a button.colab-df-convert');
        buttonEl.style.display =
          google.colab.kernel.accessAllowed ? 'block' : 'none';

        async function convertToInteractive(key) {
          const element = document.querySelector('#df-2a8ac683-60e0-43dd-8818-f09f9f5c749a');
          const dataTable =
            await google.colab.kernel.invokeFunction('convertToInteractive',
                                                     [key], {});
          if (!dataTable) return;

          const docLinkHtml = 'Like what you see? Visit the ' +
            '<a target="_blank" href=https://colab.research.google.com/notebooks/data_table.ipynb>data table notebook</a>'
            + ' to learn more about interactive tables.';
          element.innerHTML = '';
          dataTable['output_type'] = 'display_data';
          await google.colab.output.renderOutput(dataTable, element);
          const docLink = document.createElement('div');
          docLink.innerHTML = docLinkHtml;
          element.appendChild(docLink);
        }
      </script>
    </div>
  </div>





```python
# Create the test pandas dataframe in pandas by reading the csv, remember to parse the datetime!
test = pd.read_csv('test.csv', parse_dates=['datetime'])
test.head()

# Both registered and casual are only found in test.
```





  <div id="df-2885a63e-946d-4bc5-b31d-c365ca33e164">
    <div class="colab-df-container">
      <div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>datetime</th>
      <th>season</th>
      <th>holiday</th>
      <th>workingday</th>
      <th>weather</th>
      <th>temp</th>
      <th>atemp</th>
      <th>humidity</th>
      <th>windspeed</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2011-01-20 00:00:00</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>10.66</td>
      <td>11.365</td>
      <td>56</td>
      <td>26.0027</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2011-01-20 01:00:00</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>10.66</td>
      <td>13.635</td>
      <td>56</td>
      <td>0.0000</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2011-01-20 02:00:00</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>10.66</td>
      <td>13.635</td>
      <td>56</td>
      <td>0.0000</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2011-01-20 03:00:00</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>10.66</td>
      <td>12.880</td>
      <td>56</td>
      <td>11.0014</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2011-01-20 04:00:00</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>10.66</td>
      <td>12.880</td>
      <td>56</td>
      <td>11.0014</td>
    </tr>
  </tbody>
</table>
</div>
      <button class="colab-df-convert" onclick="convertToInteractive('df-2885a63e-946d-4bc5-b31d-c365ca33e164')"
              title="Convert this dataframe to an interactive table."
              style="display:none;">

  <svg xmlns="http://www.w3.org/2000/svg" height="24px"viewBox="0 0 24 24"
       width="24px">
    <path d="M0 0h24v24H0V0z" fill="none"/>
    <path d="M18.56 5.44l.94 2.06.94-2.06 2.06-.94-2.06-.94-.94-2.06-.94 2.06-2.06.94zm-11 1L8.5 8.5l.94-2.06 2.06-.94-2.06-.94L8.5 2.5l-.94 2.06-2.06.94zm10 10l.94 2.06.94-2.06 2.06-.94-2.06-.94-.94-2.06-.94 2.06-2.06.94z"/><path d="M17.41 7.96l-1.37-1.37c-.4-.4-.92-.59-1.43-.59-.52 0-1.04.2-1.43.59L10.3 9.45l-7.72 7.72c-.78.78-.78 2.05 0 2.83L4 21.41c.39.39.9.59 1.41.59.51 0 1.02-.2 1.41-.59l7.78-7.78 2.81-2.81c.8-.78.8-2.07 0-2.86zM5.41 20L4 18.59l7.72-7.72 1.47 1.35L5.41 20z"/>
  </svg>
      </button>

  <style>
    .colab-df-container {
      display:flex;
      flex-wrap:wrap;
      gap: 12px;
    }

    .colab-df-convert {
      background-color: #E8F0FE;
      border: none;
      border-radius: 50%;
      cursor: pointer;
      display: none;
      fill: #1967D2;
      height: 32px;
      padding: 0 0 0 0;
      width: 32px;
    }

    .colab-df-convert:hover {
      background-color: #E2EBFA;
      box-shadow: 0px 1px 2px rgba(60, 64, 67, 0.3), 0px 1px 3px 1px rgba(60, 64, 67, 0.15);
      fill: #174EA6;
    }

    [theme=dark] .colab-df-convert {
      background-color: #3B4455;
      fill: #D2E3FC;
    }

    [theme=dark] .colab-df-convert:hover {
      background-color: #434B5C;
      box-shadow: 0px 1px 3px 1px rgba(0, 0, 0, 0.15);
      filter: drop-shadow(0px 1px 2px rgba(0, 0, 0, 0.3));
      fill: #FFFFFF;
    }
  </style>

      <script>
        const buttonEl =
          document.querySelector('#df-2885a63e-946d-4bc5-b31d-c365ca33e164 button.colab-df-convert');
        buttonEl.style.display =
          google.colab.kernel.accessAllowed ? 'block' : 'none';

        async function convertToInteractive(key) {
          const element = document.querySelector('#df-2885a63e-946d-4bc5-b31d-c365ca33e164');
          const dataTable =
            await google.colab.kernel.invokeFunction('convertToInteractive',
                                                     [key], {});
          if (!dataTable) return;

          const docLinkHtml = 'Like what you see? Visit the ' +
            '<a target="_blank" href=https://colab.research.google.com/notebooks/data_table.ipynb>data table notebook</a>'
            + ' to learn more about interactive tables.';
          element.innerHTML = '';
          dataTable['output_type'] = 'display_data';
          await google.colab.output.renderOutput(dataTable, element);
          const docLink = document.createElement('div');
          docLink.innerHTML = docLinkHtml;
          element.appendChild(docLink);
        }
      </script>
    </div>
  </div>





```python
test.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 6493 entries, 0 to 6492
    Data columns (total 9 columns):
     #   Column      Non-Null Count  Dtype         
    ---  ------      --------------  -----         
     0   datetime    6493 non-null   datetime64[ns]
     1   season      6493 non-null   int64         
     2   holiday     6493 non-null   int64         
     3   workingday  6493 non-null   int64         
     4   weather     6493 non-null   int64         
     5   temp        6493 non-null   float64       
     6   atemp       6493 non-null   float64       
     7   humidity    6493 non-null   int64         
     8   windspeed   6493 non-null   float64       
    dtypes: datetime64[ns](1), float64(3), int64(5)
    memory usage: 456.7 KB



```python
# Same thing as train and test dataset
submission = pd.read_csv('sampleSubmission.csv', parse_dates=['datetime'])
submission.head()
```





  <div id="df-5b20a9f0-0ed7-4e42-affb-8e90ee761db9">
    <div class="colab-df-container">
      <div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>datetime</th>
      <th>count</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2011-01-20 00:00:00</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2011-01-20 01:00:00</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2011-01-20 02:00:00</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2011-01-20 03:00:00</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2011-01-20 04:00:00</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>
      <button class="colab-df-convert" onclick="convertToInteractive('df-5b20a9f0-0ed7-4e42-affb-8e90ee761db9')"
              title="Convert this dataframe to an interactive table."
              style="display:none;">

  <svg xmlns="http://www.w3.org/2000/svg" height="24px"viewBox="0 0 24 24"
       width="24px">
    <path d="M0 0h24v24H0V0z" fill="none"/>
    <path d="M18.56 5.44l.94 2.06.94-2.06 2.06-.94-2.06-.94-.94-2.06-.94 2.06-2.06.94zm-11 1L8.5 8.5l.94-2.06 2.06-.94-2.06-.94L8.5 2.5l-.94 2.06-2.06.94zm10 10l.94 2.06.94-2.06 2.06-.94-2.06-.94-.94-2.06-.94 2.06-2.06.94z"/><path d="M17.41 7.96l-1.37-1.37c-.4-.4-.92-.59-1.43-.59-.52 0-1.04.2-1.43.59L10.3 9.45l-7.72 7.72c-.78.78-.78 2.05 0 2.83L4 21.41c.39.39.9.59 1.41.59.51 0 1.02-.2 1.41-.59l7.78-7.78 2.81-2.81c.8-.78.8-2.07 0-2.86zM5.41 20L4 18.59l7.72-7.72 1.47 1.35L5.41 20z"/>
  </svg>
      </button>

  <style>
    .colab-df-container {
      display:flex;
      flex-wrap:wrap;
      gap: 12px;
    }

    .colab-df-convert {
      background-color: #E8F0FE;
      border: none;
      border-radius: 50%;
      cursor: pointer;
      display: none;
      fill: #1967D2;
      height: 32px;
      padding: 0 0 0 0;
      width: 32px;
    }

    .colab-df-convert:hover {
      background-color: #E2EBFA;
      box-shadow: 0px 1px 2px rgba(60, 64, 67, 0.3), 0px 1px 3px 1px rgba(60, 64, 67, 0.15);
      fill: #174EA6;
    }

    [theme=dark] .colab-df-convert {
      background-color: #3B4455;
      fill: #D2E3FC;
    }

    [theme=dark] .colab-df-convert:hover {
      background-color: #434B5C;
      box-shadow: 0px 1px 3px 1px rgba(0, 0, 0, 0.15);
      filter: drop-shadow(0px 1px 2px rgba(0, 0, 0, 0.3));
      fill: #FFFFFF;
    }
  </style>

      <script>
        const buttonEl =
          document.querySelector('#df-5b20a9f0-0ed7-4e42-affb-8e90ee761db9 button.colab-df-convert');
        buttonEl.style.display =
          google.colab.kernel.accessAllowed ? 'block' : 'none';

        async function convertToInteractive(key) {
          const element = document.querySelector('#df-5b20a9f0-0ed7-4e42-affb-8e90ee761db9');
          const dataTable =
            await google.colab.kernel.invokeFunction('convertToInteractive',
                                                     [key], {});
          if (!dataTable) return;

          const docLinkHtml = 'Like what you see? Visit the ' +
            '<a target="_blank" href=https://colab.research.google.com/notebooks/data_table.ipynb>data table notebook</a>'
            + ' to learn more about interactive tables.';
          element.innerHTML = '';
          dataTable['output_type'] = 'display_data';
          await google.colab.output.renderOutput(dataTable, element);
          const docLink = document.createElement('div');
          docLink.innerHTML = docLinkHtml;
          element.appendChild(docLink);
        }
      </script>
    </div>
  </div>




## Step 3: Train a model using AutoGluon’s Tabular Prediction

Requirements:
* We are prediting `count`, so it is the label we are setting.
* Ignore `casual` and `registered` columns as they are also not present in the test dataset. 
* Use the `root_mean_squared_error` as the metric to use for evaluation.
* Set a time limit of 10 minutes (600 seconds).
* Use the preset `best_quality` to focus on creating the best model.


```python
# remove casual and registered columns
df_train_cols = train.columns.to_list()
df_train_cols.remove('casual')
df_train_cols.remove('registered')

df_train = train[df_train_cols]
df_train.head()
```





  <div id="df-344cf7d8-b2c5-4c48-ba6f-271d499b14a4">
    <div class="colab-df-container">
      <div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>datetime</th>
      <th>season</th>
      <th>holiday</th>
      <th>workingday</th>
      <th>weather</th>
      <th>temp</th>
      <th>atemp</th>
      <th>humidity</th>
      <th>windspeed</th>
      <th>count</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2011-01-01 00:00:00</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>9.84</td>
      <td>14.395</td>
      <td>81</td>
      <td>0.0</td>
      <td>16</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2011-01-01 01:00:00</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>9.02</td>
      <td>13.635</td>
      <td>80</td>
      <td>0.0</td>
      <td>40</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2011-01-01 02:00:00</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>9.02</td>
      <td>13.635</td>
      <td>80</td>
      <td>0.0</td>
      <td>32</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2011-01-01 03:00:00</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>9.84</td>
      <td>14.395</td>
      <td>75</td>
      <td>0.0</td>
      <td>13</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2011-01-01 04:00:00</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>9.84</td>
      <td>14.395</td>
      <td>75</td>
      <td>0.0</td>
      <td>1</td>
    </tr>
  </tbody>
</table>
</div>
      <button class="colab-df-convert" onclick="convertToInteractive('df-344cf7d8-b2c5-4c48-ba6f-271d499b14a4')"
              title="Convert this dataframe to an interactive table."
              style="display:none;">

  <svg xmlns="http://www.w3.org/2000/svg" height="24px"viewBox="0 0 24 24"
       width="24px">
    <path d="M0 0h24v24H0V0z" fill="none"/>
    <path d="M18.56 5.44l.94 2.06.94-2.06 2.06-.94-2.06-.94-.94-2.06-.94 2.06-2.06.94zm-11 1L8.5 8.5l.94-2.06 2.06-.94-2.06-.94L8.5 2.5l-.94 2.06-2.06.94zm10 10l.94 2.06.94-2.06 2.06-.94-2.06-.94-.94-2.06-.94 2.06-2.06.94z"/><path d="M17.41 7.96l-1.37-1.37c-.4-.4-.92-.59-1.43-.59-.52 0-1.04.2-1.43.59L10.3 9.45l-7.72 7.72c-.78.78-.78 2.05 0 2.83L4 21.41c.39.39.9.59 1.41.59.51 0 1.02-.2 1.41-.59l7.78-7.78 2.81-2.81c.8-.78.8-2.07 0-2.86zM5.41 20L4 18.59l7.72-7.72 1.47 1.35L5.41 20z"/>
  </svg>
      </button>

  <style>
    .colab-df-container {
      display:flex;
      flex-wrap:wrap;
      gap: 12px;
    }

    .colab-df-convert {
      background-color: #E8F0FE;
      border: none;
      border-radius: 50%;
      cursor: pointer;
      display: none;
      fill: #1967D2;
      height: 32px;
      padding: 0 0 0 0;
      width: 32px;
    }

    .colab-df-convert:hover {
      background-color: #E2EBFA;
      box-shadow: 0px 1px 2px rgba(60, 64, 67, 0.3), 0px 1px 3px 1px rgba(60, 64, 67, 0.15);
      fill: #174EA6;
    }

    [theme=dark] .colab-df-convert {
      background-color: #3B4455;
      fill: #D2E3FC;
    }

    [theme=dark] .colab-df-convert:hover {
      background-color: #434B5C;
      box-shadow: 0px 1px 3px 1px rgba(0, 0, 0, 0.15);
      filter: drop-shadow(0px 1px 2px rgba(0, 0, 0, 0.3));
      fill: #FFFFFF;
    }
  </style>

      <script>
        const buttonEl =
          document.querySelector('#df-344cf7d8-b2c5-4c48-ba6f-271d499b14a4 button.colab-df-convert');
        buttonEl.style.display =
          google.colab.kernel.accessAllowed ? 'block' : 'none';

        async function convertToInteractive(key) {
          const element = document.querySelector('#df-344cf7d8-b2c5-4c48-ba6f-271d499b14a4');
          const dataTable =
            await google.colab.kernel.invokeFunction('convertToInteractive',
                                                     [key], {});
          if (!dataTable) return;

          const docLinkHtml = 'Like what you see? Visit the ' +
            '<a target="_blank" href=https://colab.research.google.com/notebooks/data_table.ipynb>data table notebook</a>'
            + ' to learn more about interactive tables.';
          element.innerHTML = '';
          dataTable['output_type'] = 'display_data';
          await google.colab.output.renderOutput(dataTable, element);
          const docLink = document.createElement('div');
          docLink.innerHTML = docLinkHtml;
          element.appendChild(docLink);
        }
      </script>
    </div>
  </div>





```python
predictor = TabularPredictor(
    label='count', 
    problem_type='regression', 
    eval_metric='root_mean_squared_error'
    ).fit(
    train_data=df_train, 
    time_limit=600, 
    presets='best_quality', 
    )
```

    No path specified. Models will be saved in: "AutogluonModels/ag-20230522_154452/"
    Presets specified: ['best_quality']
    Stack configuration (auto_stack=True): num_stack_levels=1, num_bag_folds=8, num_bag_sets=20
    Beginning AutoGluon training ... Time limit = 600s
    AutoGluon will save models to "AutogluonModels/ag-20230522_154452/"
    AutoGluon Version:  0.7.0
    Python Version:     3.10.11
    Operating System:   Linux
    Platform Machine:   x86_64
    Platform Version:   #1 SMP Sat Apr 29 09:15:28 UTC 2023
    Train Data Rows:    10886
    Train Data Columns: 9
    Label Column: count
    Preprocessing data ...
    Using Feature Generators to preprocess the data ...
    Fitting AutoMLPipelineFeatureGenerator...
    	Available Memory:                    10245.06 MB
    	Train Data (Original)  Memory Usage: 0.78 MB (0.0% of available memory)
    	Inferring data type of each feature based on column values. Set feature_metadata_in to manually specify special dtypes of the features.
    	Stage 1 Generators:
    		Fitting AsTypeFeatureGenerator...
    			Note: Converting 2 features to boolean dtype as they only contain 2 unique values.
    	Stage 2 Generators:
    		Fitting FillNaFeatureGenerator...
    	Stage 3 Generators:
    		Fitting IdentityFeatureGenerator...
    		Fitting DatetimeFeatureGenerator...
    	Stage 4 Generators:
    		Fitting DropUniqueFeatureGenerator...
    	Types of features in original data (raw dtype, special dtypes):
    		('datetime', []) : 1 | ['datetime']
    		('float', [])    : 3 | ['temp', 'atemp', 'windspeed']
    		('int', [])      : 5 | ['season', 'holiday', 'workingday', 'weather', 'humidity']
    	Types of features in processed data (raw dtype, special dtypes):
    		('float', [])                : 3 | ['temp', 'atemp', 'windspeed']
    		('int', [])                  : 3 | ['season', 'weather', 'humidity']
    		('int', ['bool'])            : 2 | ['holiday', 'workingday']
    		('int', ['datetime_as_int']) : 5 | ['datetime', 'datetime.year', 'datetime.month', 'datetime.day', 'datetime.dayofweek']
    	0.6s = Fit runtime
    	9 features in original data used to generate 13 features in processed data.
    	Train Data (Processed) Memory Usage: 0.98 MB (0.0% of available memory)
    Data preprocessing and feature engineering runtime = 0.72s ...
    AutoGluon will gauge predictive performance using evaluation metric: 'root_mean_squared_error'
    	This metric's sign has been flipped to adhere to being higher_is_better. The metric score can be multiplied by -1 to get the metric value.
    	To change this, specify the eval_metric parameter of Predictor()
    AutoGluon will fit 2 stack levels (L1 to L2) ...
    Fitting 11 L1 models ...
    Fitting model: KNeighborsUnif_BAG_L1 ... Training model for up to 399.42s of the 599.27s of remaining time.
    	-101.5462	 = Validation score   (-root_mean_squared_error)
    	0.23s	 = Training   runtime
    	0.15s	 = Validation runtime
    Fitting model: KNeighborsDist_BAG_L1 ... Training model for up to 381.12s of the 580.97s of remaining time.
    	-84.1251	 = Validation score   (-root_mean_squared_error)
    	0.15s	 = Training   runtime
    	0.14s	 = Validation runtime
    Fitting model: LightGBMXT_BAG_L1 ... Training model for up to 380.72s of the 580.56s of remaining time.
    	Fitting 8 child models (S1F1 - S1F8) | Fitting with ParallelLocalFoldFittingStrategy
    	-131.4609	 = Validation score   (-root_mean_squared_error)
    	101.75s	 = Training   runtime
    	26.22s	 = Validation runtime
    Fitting model: LightGBM_BAG_L1 ... Training model for up to 251.33s of the 451.18s of remaining time.
    	Fitting 8 child models (S1F1 - S1F8) | Fitting with ParallelLocalFoldFittingStrategy
    	-131.0542	 = Validation score   (-root_mean_squared_error)
    	61.31s	 = Training   runtime
    	4.53s	 = Validation runtime
    Fitting model: RandomForestMSE_BAG_L1 ... Training model for up to 179.93s of the 379.78s of remaining time.
    	-116.5484	 = Validation score   (-root_mean_squared_error)
    	19.87s	 = Training   runtime
    	0.66s	 = Validation runtime
    Fitting model: CatBoost_BAG_L1 ... Training model for up to 158.3s of the 358.15s of remaining time.
    	Fitting 8 child models (S1F1 - S1F8) | Fitting with ParallelLocalFoldFittingStrategy
    	-130.938	 = Validation score   (-root_mean_squared_error)
    	149.16s	 = Training   runtime
    	0.28s	 = Validation runtime
    Fitting model: ExtraTreesMSE_BAG_L1 ... Training model for up to 5.09s of the 204.93s of remaining time.
    	-124.6007	 = Validation score   (-root_mean_squared_error)
    	11.71s	 = Training   runtime
    	0.59s	 = Validation runtime
    Completed 1/20 k-fold bagging repeats ...
    Fitting model: WeightedEnsemble_L2 ... Training model for up to 360.0s of the 190.06s of remaining time.
    	-84.1251	 = Validation score   (-root_mean_squared_error)
    	0.47s	 = Training   runtime
    	0.0s	 = Validation runtime
    Fitting 9 L2 models ...
    Fitting model: LightGBMXT_BAG_L2 ... Training model for up to 189.56s of the 189.54s of remaining time.
    	Fitting 8 child models (S1F1 - S1F8) | Fitting with ParallelLocalFoldFittingStrategy
    	-60.4127	 = Validation score   (-root_mean_squared_error)
    	86.79s	 = Training   runtime
    	8.46s	 = Validation runtime
    Fitting model: LightGBM_BAG_L2 ... Training model for up to 97.3s of the 97.28s of remaining time.
    	Fitting 8 child models (S1F1 - S1F8) | Fitting with ParallelLocalFoldFittingStrategy
    	-55.0593	 = Validation score   (-root_mean_squared_error)
    	39.76s	 = Training   runtime
    	0.93s	 = Validation runtime
    Fitting model: RandomForestMSE_BAG_L2 ... Training model for up to 52.39s of the 52.38s of remaining time.
    	-53.4309	 = Validation score   (-root_mean_squared_error)
    	41.51s	 = Training   runtime
    	1.12s	 = Validation runtime
    Fitting model: CatBoost_BAG_L2 ... Training model for up to 8.59s of the 8.56s of remaining time.
    	Fitting 8 child models (S1F1 - S1F8) | Fitting with ParallelLocalFoldFittingStrategy
    	Time limit exceeded... Skipping CatBoost_BAG_L2.
    2023-05-22 15:54:52,455	ERROR worker.py:400 -- Unhandled error (suppress with 'RAY_IGNORE_UNHANDLED_ERRORS=1'): The worker died unexpectedly while executing this task. Check python-core-worker-*.log files for more information.
    Completed 1/20 k-fold bagging repeats ...
    Fitting model: WeightedEnsemble_L3 ... Training model for up to 360.0s of the -0.31s of remaining time.
    	-53.101	 = Validation score   (-root_mean_squared_error)
    	0.41s	 = Training   runtime
    	0.0s	 = Validation runtime
    AutoGluon training complete, total runtime = 600.8s ... Best model: "WeightedEnsemble_L3"
    TabularPredictor saved. To load, use: predictor = TabularPredictor.load("AutogluonModels/ag-20230522_154452/")


### Review AutoGluon's training run with ranking of models that did the best.


```python
predictor.fit_summary()
```

    *** Summary of fit() ***
    Estimated performance of each model:
                         model   score_val  pred_time_val    fit_time  pred_time_val_marginal  fit_time_marginal  stack_level  can_infer  fit_order
    0      WeightedEnsemble_L3  -53.101015      43.086408  512.647247                0.001273           0.408845            3       True         12
    1   RandomForestMSE_BAG_L2  -53.430898      33.688063  385.695601                1.119493          41.511842            2       True         11
    2          LightGBM_BAG_L2  -55.059299      33.502738  383.939682                0.934169          39.755922            2       True         10
    3        LightGBMXT_BAG_L2  -60.412687      41.031473  430.970638                8.462903          86.786878            2       True          9
    4    KNeighborsDist_BAG_L1  -84.125061       0.136730    0.149525                0.136730           0.149525            1       True          2
    5      WeightedEnsemble_L2  -84.125061       0.138021    0.623135                0.001291           0.473610            2       True          8
    6    KNeighborsUnif_BAG_L1 -101.546199       0.151225    0.226095                0.151225           0.226095            1       True          1
    7   RandomForestMSE_BAG_L1 -116.548359       0.657503   19.873196                0.657503          19.873196            1       True          5
    8     ExtraTreesMSE_BAG_L1 -124.600676       0.593104   11.711914                0.593104          11.711914            1       True          7
    9          CatBoost_BAG_L1 -130.937969       0.279127  149.158596                0.279127         149.158596            1       True          6
    10         LightGBM_BAG_L1 -131.054162       4.527501   61.313230                4.527501          61.313230            1       True          4
    11       LightGBMXT_BAG_L1 -131.460909      26.223379  101.751203               26.223379         101.751203            1       True          3
    Number of models trained: 12
    Types of models trained:
    {'StackerEnsembleModel_CatBoost', 'StackerEnsembleModel_KNN', 'WeightedEnsembleModel', 'StackerEnsembleModel_RF', 'StackerEnsembleModel_LGB', 'StackerEnsembleModel_XT'}
    Bagging used: True  (with 8 folds)
    Multi-layer stack-ensembling used: True  (with 3 levels)
    Feature Metadata (Processed):
    (raw dtype, special dtypes):
    ('float', [])                : 3 | ['temp', 'atemp', 'windspeed']
    ('int', [])                  : 3 | ['season', 'weather', 'humidity']
    ('int', ['bool'])            : 2 | ['holiday', 'workingday']
    ('int', ['datetime_as_int']) : 5 | ['datetime', 'datetime.year', 'datetime.month', 'datetime.day', 'datetime.dayofweek']
    *** End of fit() summary ***


    /usr/local/lib/python3.10/dist-packages/autogluon/core/utils/plots.py:138: UserWarning: AutoGluon summary plots cannot be created because bokeh is not installed. To see plots, please do: "pip install bokeh==2.0.1"
      warnings.warn('AutoGluon summary plots cannot be created because bokeh is not installed. To see plots, please do: "pip install bokeh==2.0.1"')





    {'model_types': {'KNeighborsUnif_BAG_L1': 'StackerEnsembleModel_KNN',
      'KNeighborsDist_BAG_L1': 'StackerEnsembleModel_KNN',
      'LightGBMXT_BAG_L1': 'StackerEnsembleModel_LGB',
      'LightGBM_BAG_L1': 'StackerEnsembleModel_LGB',
      'RandomForestMSE_BAG_L1': 'StackerEnsembleModel_RF',
      'CatBoost_BAG_L1': 'StackerEnsembleModel_CatBoost',
      'ExtraTreesMSE_BAG_L1': 'StackerEnsembleModel_XT',
      'WeightedEnsemble_L2': 'WeightedEnsembleModel',
      'LightGBMXT_BAG_L2': 'StackerEnsembleModel_LGB',
      'LightGBM_BAG_L2': 'StackerEnsembleModel_LGB',
      'RandomForestMSE_BAG_L2': 'StackerEnsembleModel_RF',
      'WeightedEnsemble_L3': 'WeightedEnsembleModel'},
     'model_performance': {'KNeighborsUnif_BAG_L1': -101.54619908446061,
      'KNeighborsDist_BAG_L1': -84.12506123181602,
      'LightGBMXT_BAG_L1': -131.46090891834504,
      'LightGBM_BAG_L1': -131.054161598899,
      'RandomForestMSE_BAG_L1': -116.54835939455667,
      'CatBoost_BAG_L1': -130.9379689394935,
      'ExtraTreesMSE_BAG_L1': -124.60067564699747,
      'WeightedEnsemble_L2': -84.12506123181602,
      'LightGBMXT_BAG_L2': -60.41268657634194,
      'LightGBM_BAG_L2': -55.059299349174594,
      'RandomForestMSE_BAG_L2': -53.43089766271705,
      'WeightedEnsemble_L3': -53.101015492617606},
     'model_best': 'WeightedEnsemble_L3',
     'model_paths': {'KNeighborsUnif_BAG_L1': 'AutogluonModels/ag-20230522_154452/models/KNeighborsUnif_BAG_L1/',
      'KNeighborsDist_BAG_L1': 'AutogluonModels/ag-20230522_154452/models/KNeighborsDist_BAG_L1/',
      'LightGBMXT_BAG_L1': 'AutogluonModels/ag-20230522_154452/models/LightGBMXT_BAG_L1/',
      'LightGBM_BAG_L1': 'AutogluonModels/ag-20230522_154452/models/LightGBM_BAG_L1/',
      'RandomForestMSE_BAG_L1': 'AutogluonModels/ag-20230522_154452/models/RandomForestMSE_BAG_L1/',
      'CatBoost_BAG_L1': 'AutogluonModels/ag-20230522_154452/models/CatBoost_BAG_L1/',
      'ExtraTreesMSE_BAG_L1': 'AutogluonModels/ag-20230522_154452/models/ExtraTreesMSE_BAG_L1/',
      'WeightedEnsemble_L2': 'AutogluonModels/ag-20230522_154452/models/WeightedEnsemble_L2/',
      'LightGBMXT_BAG_L2': 'AutogluonModels/ag-20230522_154452/models/LightGBMXT_BAG_L2/',
      'LightGBM_BAG_L2': 'AutogluonModels/ag-20230522_154452/models/LightGBM_BAG_L2/',
      'RandomForestMSE_BAG_L2': 'AutogluonModels/ag-20230522_154452/models/RandomForestMSE_BAG_L2/',
      'WeightedEnsemble_L3': 'AutogluonModels/ag-20230522_154452/models/WeightedEnsemble_L3/'},
     'model_fit_times': {'KNeighborsUnif_BAG_L1': 0.22609496116638184,
      'KNeighborsDist_BAG_L1': 0.14952492713928223,
      'LightGBMXT_BAG_L1': 101.75120306015015,
      'LightGBM_BAG_L1': 61.31322979927063,
      'RandomForestMSE_BAG_L1': 19.873196363449097,
      'CatBoost_BAG_L1': 149.15859580039978,
      'ExtraTreesMSE_BAG_L1': 11.711914300918579,
      'WeightedEnsemble_L2': 0.47360992431640625,
      'LightGBMXT_BAG_L2': 86.78687834739685,
      'LightGBM_BAG_L2': 39.75592231750488,
      'RandomForestMSE_BAG_L2': 41.511842012405396,
      'WeightedEnsemble_L3': 0.4088447093963623},
     'model_pred_times': {'KNeighborsUnif_BAG_L1': 0.15122485160827637,
      'KNeighborsDist_BAG_L1': 0.13673019409179688,
      'LightGBMXT_BAG_L1': 26.223378658294678,
      'LightGBM_BAG_L1': 4.527500867843628,
      'RandomForestMSE_BAG_L1': 0.6575033664703369,
      'CatBoost_BAG_L1': 0.2791273593902588,
      'ExtraTreesMSE_BAG_L1': 0.593104362487793,
      'WeightedEnsemble_L2': 0.0012912750244140625,
      'LightGBMXT_BAG_L2': 8.462903499603271,
      'LightGBM_BAG_L2': 0.9341685771942139,
      'RandomForestMSE_BAG_L2': 1.1194932460784912,
      'WeightedEnsemble_L3': 0.0012726783752441406},
     'num_bag_folds': 8,
     'max_stack_level': 3,
     'model_hyperparams': {'KNeighborsUnif_BAG_L1': {'use_orig_features': True,
       'max_base_models': 25,
       'max_base_models_per_type': 5,
       'save_bag_folds': True,
       'use_child_oof': True},
      'KNeighborsDist_BAG_L1': {'use_orig_features': True,
       'max_base_models': 25,
       'max_base_models_per_type': 5,
       'save_bag_folds': True,
       'use_child_oof': True},
      'LightGBMXT_BAG_L1': {'use_orig_features': True,
       'max_base_models': 25,
       'max_base_models_per_type': 5,
       'save_bag_folds': True},
      'LightGBM_BAG_L1': {'use_orig_features': True,
       'max_base_models': 25,
       'max_base_models_per_type': 5,
       'save_bag_folds': True},
      'RandomForestMSE_BAG_L1': {'use_orig_features': True,
       'max_base_models': 25,
       'max_base_models_per_type': 5,
       'save_bag_folds': True,
       'use_child_oof': True},
      'CatBoost_BAG_L1': {'use_orig_features': True,
       'max_base_models': 25,
       'max_base_models_per_type': 5,
       'save_bag_folds': True},
      'ExtraTreesMSE_BAG_L1': {'use_orig_features': True,
       'max_base_models': 25,
       'max_base_models_per_type': 5,
       'save_bag_folds': True,
       'use_child_oof': True},
      'WeightedEnsemble_L2': {'use_orig_features': False,
       'max_base_models': 25,
       'max_base_models_per_type': 5,
       'save_bag_folds': True},
      'LightGBMXT_BAG_L2': {'use_orig_features': True,
       'max_base_models': 25,
       'max_base_models_per_type': 5,
       'save_bag_folds': True},
      'LightGBM_BAG_L2': {'use_orig_features': True,
       'max_base_models': 25,
       'max_base_models_per_type': 5,
       'save_bag_folds': True},
      'RandomForestMSE_BAG_L2': {'use_orig_features': True,
       'max_base_models': 25,
       'max_base_models_per_type': 5,
       'save_bag_folds': True,
       'use_child_oof': True},
      'WeightedEnsemble_L3': {'use_orig_features': False,
       'max_base_models': 25,
       'max_base_models_per_type': 5,
       'save_bag_folds': True}},
     'leaderboard':                      model   score_val  pred_time_val    fit_time  \
     0      WeightedEnsemble_L3  -53.101015      43.086408  512.647247   
     1   RandomForestMSE_BAG_L2  -53.430898      33.688063  385.695601   
     2          LightGBM_BAG_L2  -55.059299      33.502738  383.939682   
     3        LightGBMXT_BAG_L2  -60.412687      41.031473  430.970638   
     4    KNeighborsDist_BAG_L1  -84.125061       0.136730    0.149525   
     5      WeightedEnsemble_L2  -84.125061       0.138021    0.623135   
     6    KNeighborsUnif_BAG_L1 -101.546199       0.151225    0.226095   
     7   RandomForestMSE_BAG_L1 -116.548359       0.657503   19.873196   
     8     ExtraTreesMSE_BAG_L1 -124.600676       0.593104   11.711914   
     9          CatBoost_BAG_L1 -130.937969       0.279127  149.158596   
     10         LightGBM_BAG_L1 -131.054162       4.527501   61.313230   
     11       LightGBMXT_BAG_L1 -131.460909      26.223379  101.751203   
     
         pred_time_val_marginal  fit_time_marginal  stack_level  can_infer  \
     0                 0.001273           0.408845            3       True   
     1                 1.119493          41.511842            2       True   
     2                 0.934169          39.755922            2       True   
     3                 8.462903          86.786878            2       True   
     4                 0.136730           0.149525            1       True   
     5                 0.001291           0.473610            2       True   
     6                 0.151225           0.226095            1       True   
     7                 0.657503          19.873196            1       True   
     8                 0.593104          11.711914            1       True   
     9                 0.279127         149.158596            1       True   
     10                4.527501          61.313230            1       True   
     11               26.223379         101.751203            1       True   
     
         fit_order  
     0          12  
     1          11  
     2          10  
     3           9  
     4           2  
     5           8  
     6           1  
     7           5  
     8           7  
     9           6  
     10          4  
     11          3  }



### Create predictions from test dataset


```python
predictions = predictor.predict(test, as_pandas=True)
predictions.head()
```




    0    23.592808
    1    42.984993
    2    45.910057
    3    49.038399
    4    52.123993
    Name: count, dtype: float32



#### NOTE: Kaggle will reject the submission if we don't set everything to be > 0.


```python
# Describe the `predictions` series to see if there are any negative values
predictions.describe()
```




    count    6493.000000
    mean      100.536247
    std        89.953094
    min         3.073805
    25%        19.846375
    50%        64.396080
    75%       167.207855
    max       368.366089
    Name: count, dtype: float64




```python
# How many negative values do we have?
(predictions < 0).sum()
```




    0




```python
# Set them to zero
predictions[predictions < 0] = 0
```

### Set predictions to submission dataframe, save, and submit


```python
submission["count"] = predictions
submission.to_csv("submission.csv", index=False)
```


```python
!kaggle competitions submit -c bike-sharing-demand -f submission.csv -m "first raw submission"
```

    100% 188k/188k [00:00<00:00, 234kB/s]
    Successfully submitted to Bike Sharing Demand

#### View submission via the command line or in the web browser under the competition's page - `My Submissions`


```python
!kaggle competitions submissions -c bike-sharing-demand | tail -n +1 | head -n 6
```

    fileName        date                 description           status    publicScore  privateScore  
    --------------  -------------------  --------------------  --------  -----------  ------------  
    submission.csv  2023-05-22 15:56:20  first raw submission  complete  1.80405      1.80405       


#### Initial score of 1.80405

## Step 4: Exploratory Data Analysis and Creating an additional feature
* Any additional feature will do, but a great suggestion would be to separate out the datetime into hour, day, or month parts.


```python
# Create a histogram of all features to show the distribution of each one relative to the data. This is part of the exploritory data analysis
train.hist(figsize=(15,15))
```




    array([[<Axes: title={'center': 'datetime'}>,
            <Axes: title={'center': 'season'}>,
            <Axes: title={'center': 'holiday'}>],
           [<Axes: title={'center': 'workingday'}>,
            <Axes: title={'center': 'weather'}>,
            <Axes: title={'center': 'temp'}>],
           [<Axes: title={'center': 'atemp'}>,
            <Axes: title={'center': 'humidity'}>,
            <Axes: title={'center': 'windspeed'}>],
           [<Axes: title={'center': 'casual'}>,
            <Axes: title={'center': 'registered'}>,
            <Axes: title={'center': 'count'}>]], dtype=object)




    
![png](output_45_1.png)
    


## Examining day time statistics


```python
# Examining years available
print("years in training data : ", train.datetime.dt.year.unique())
print("years in test data : ", test.datetime.dt.year.unique())
print("####")

# Examining months available
print("Months available in training data : ", train.datetime.dt.month.unique())
print("Months available in test data : ", test.datetime.dt.month.unique())
print("####")

# Examining days available
print("Days available in training data : ", train.datetime.dt.day.unique())
print("Days available in test data : ", test.datetime.dt.day.unique())
print("####")

# Examining hours available
print("Hours available in training data : ", train.datetime.dt.hour.unique())
print("Hours available in test data : ", test.datetime.dt.hour.unique())
print("####")

```

    years in training data :  [2011 2012]
    years in test data :  [2011 2012]
    ####
    Months available in training data :  [ 1  2  3  4  5  6  7  8  9 10 11 12]
    Months available in test data :  [ 1  2  3  4  5  6  7  8  9 10 11 12]
    ####
    Days available in training data :  [ 1  2  3  4  5  6  7  8  9 10 11 12 13 14 15 16 17 18 19]
    Days available in test data :  [20 21 22 23 24 25 26 27 28 29 30 31]
    ####
    Hours available in training data :  [ 0  1  2  3  4  5  6  7  8  9 10 11 12 13 14 15 16 17 18 19 20 21 22 23]
    Hours available in test data :  [ 0  1  2  3  4  5  6  7  8  9 10 11 12 13 14 15 16 17 18 19 20 21 22 23]
    ####



```python
# create a new feature
train['hour'] = train.datetime.dt.hour
test['hour'] = test.datetime.dt.hour
```

## Make category types for these so models know they are not just numbers
* AutoGluon originally sees these as ints, but in reality they are int representations of a category.
* Setting the dtype to category will classify these as categories in AutoGluon.


```python
train["season"] = train.season.astype('category')
train["weather"] = train.weather.astype('category')
test["season"] = test.season.astype('category')
test["weather"] = test.weather.astype('category')
```


```python
# View are new feature
train.head()
```





  <div id="df-d7471225-c3c4-4b3b-9609-00bfefdc9c8a">
    <div class="colab-df-container">
      <div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>datetime</th>
      <th>season</th>
      <th>holiday</th>
      <th>workingday</th>
      <th>weather</th>
      <th>temp</th>
      <th>atemp</th>
      <th>humidity</th>
      <th>windspeed</th>
      <th>casual</th>
      <th>registered</th>
      <th>count</th>
      <th>hour</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2011-01-01 00:00:00</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>9.84</td>
      <td>14.395</td>
      <td>81</td>
      <td>0.0</td>
      <td>3</td>
      <td>13</td>
      <td>16</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2011-01-01 01:00:00</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>9.02</td>
      <td>13.635</td>
      <td>80</td>
      <td>0.0</td>
      <td>8</td>
      <td>32</td>
      <td>40</td>
      <td>1</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2011-01-01 02:00:00</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>9.02</td>
      <td>13.635</td>
      <td>80</td>
      <td>0.0</td>
      <td>5</td>
      <td>27</td>
      <td>32</td>
      <td>2</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2011-01-01 03:00:00</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>9.84</td>
      <td>14.395</td>
      <td>75</td>
      <td>0.0</td>
      <td>3</td>
      <td>10</td>
      <td>13</td>
      <td>3</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2011-01-01 04:00:00</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>9.84</td>
      <td>14.395</td>
      <td>75</td>
      <td>0.0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>4</td>
    </tr>
  </tbody>
</table>
</div>
      <button class="colab-df-convert" onclick="convertToInteractive('df-d7471225-c3c4-4b3b-9609-00bfefdc9c8a')"
              title="Convert this dataframe to an interactive table."
              style="display:none;">

  <svg xmlns="http://www.w3.org/2000/svg" height="24px"viewBox="0 0 24 24"
       width="24px">
    <path d="M0 0h24v24H0V0z" fill="none"/>
    <path d="M18.56 5.44l.94 2.06.94-2.06 2.06-.94-2.06-.94-.94-2.06-.94 2.06-2.06.94zm-11 1L8.5 8.5l.94-2.06 2.06-.94-2.06-.94L8.5 2.5l-.94 2.06-2.06.94zm10 10l.94 2.06.94-2.06 2.06-.94-2.06-.94-.94-2.06-.94 2.06-2.06.94z"/><path d="M17.41 7.96l-1.37-1.37c-.4-.4-.92-.59-1.43-.59-.52 0-1.04.2-1.43.59L10.3 9.45l-7.72 7.72c-.78.78-.78 2.05 0 2.83L4 21.41c.39.39.9.59 1.41.59.51 0 1.02-.2 1.41-.59l7.78-7.78 2.81-2.81c.8-.78.8-2.07 0-2.86zM5.41 20L4 18.59l7.72-7.72 1.47 1.35L5.41 20z"/>
  </svg>
      </button>

  <style>
    .colab-df-container {
      display:flex;
      flex-wrap:wrap;
      gap: 12px;
    }

    .colab-df-convert {
      background-color: #E8F0FE;
      border: none;
      border-radius: 50%;
      cursor: pointer;
      display: none;
      fill: #1967D2;
      height: 32px;
      padding: 0 0 0 0;
      width: 32px;
    }

    .colab-df-convert:hover {
      background-color: #E2EBFA;
      box-shadow: 0px 1px 2px rgba(60, 64, 67, 0.3), 0px 1px 3px 1px rgba(60, 64, 67, 0.15);
      fill: #174EA6;
    }

    [theme=dark] .colab-df-convert {
      background-color: #3B4455;
      fill: #D2E3FC;
    }

    [theme=dark] .colab-df-convert:hover {
      background-color: #434B5C;
      box-shadow: 0px 1px 3px 1px rgba(0, 0, 0, 0.15);
      filter: drop-shadow(0px 1px 2px rgba(0, 0, 0, 0.3));
      fill: #FFFFFF;
    }
  </style>

      <script>
        const buttonEl =
          document.querySelector('#df-d7471225-c3c4-4b3b-9609-00bfefdc9c8a button.colab-df-convert');
        buttonEl.style.display =
          google.colab.kernel.accessAllowed ? 'block' : 'none';

        async function convertToInteractive(key) {
          const element = document.querySelector('#df-d7471225-c3c4-4b3b-9609-00bfefdc9c8a');
          const dataTable =
            await google.colab.kernel.invokeFunction('convertToInteractive',
                                                     [key], {});
          if (!dataTable) return;

          const docLinkHtml = 'Like what you see? Visit the ' +
            '<a target="_blank" href=https://colab.research.google.com/notebooks/data_table.ipynb>data table notebook</a>'
            + ' to learn more about interactive tables.';
          element.innerHTML = '';
          dataTable['output_type'] = 'display_data';
          await google.colab.output.renderOutput(dataTable, element);
          const docLink = document.createElement('div');
          docLink.innerHTML = docLinkHtml;
          element.appendChild(docLink);
        }
      </script>
    </div>
  </div>





```python
# View histogram of all features again now with the hour feature
train.hist(figsize=(15,15))
```




    array([[<Axes: title={'center': 'datetime'}>,
            <Axes: title={'center': 'holiday'}>,
            <Axes: title={'center': 'workingday'}>],
           [<Axes: title={'center': 'temp'}>,
            <Axes: title={'center': 'atemp'}>,
            <Axes: title={'center': 'humidity'}>],
           [<Axes: title={'center': 'windspeed'}>,
            <Axes: title={'center': 'casual'}>,
            <Axes: title={'center': 'registered'}>],
           [<Axes: title={'center': 'count'}>,
            <Axes: title={'center': 'hour'}>, <Axes: >]], dtype=object)




    
![png](output_52_1.png)
    



```python
# hour feature histogram
ax = train['hour'].hist()
ax.set_xlabel('hour')
ax.set_ylabel('# samples')
ax.set_title('hours feature histogram')
fig = ax.get_figure()
fig.savefig('hour_feature_hist.png')
```


    
![png](output_53_0.png)
    


## Step 5: Rerun the model with the same settings as before, just with more features


```python
# remove casual and registered columns since they are not recorded in the testset
df_train_new_features_cols = train.columns.to_list()
df_train_new_features_cols.remove('casual')
df_train_new_features_cols.remove('registered')

df_train_new_features = train[df_train_new_features_cols]
df_train_new_features.head()
```





  <div id="df-f33bd0af-5042-4df9-8a76-9c43faa6938b">
    <div class="colab-df-container">
      <div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>datetime</th>
      <th>season</th>
      <th>holiday</th>
      <th>workingday</th>
      <th>weather</th>
      <th>temp</th>
      <th>atemp</th>
      <th>humidity</th>
      <th>windspeed</th>
      <th>count</th>
      <th>hour</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2011-01-01 00:00:00</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>9.84</td>
      <td>14.395</td>
      <td>81</td>
      <td>0.0</td>
      <td>16</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2011-01-01 01:00:00</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>9.02</td>
      <td>13.635</td>
      <td>80</td>
      <td>0.0</td>
      <td>40</td>
      <td>1</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2011-01-01 02:00:00</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>9.02</td>
      <td>13.635</td>
      <td>80</td>
      <td>0.0</td>
      <td>32</td>
      <td>2</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2011-01-01 03:00:00</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>9.84</td>
      <td>14.395</td>
      <td>75</td>
      <td>0.0</td>
      <td>13</td>
      <td>3</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2011-01-01 04:00:00</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>9.84</td>
      <td>14.395</td>
      <td>75</td>
      <td>0.0</td>
      <td>1</td>
      <td>4</td>
    </tr>
  </tbody>
</table>
</div>
      <button class="colab-df-convert" onclick="convertToInteractive('df-f33bd0af-5042-4df9-8a76-9c43faa6938b')"
              title="Convert this dataframe to an interactive table."
              style="display:none;">

  <svg xmlns="http://www.w3.org/2000/svg" height="24px"viewBox="0 0 24 24"
       width="24px">
    <path d="M0 0h24v24H0V0z" fill="none"/>
    <path d="M18.56 5.44l.94 2.06.94-2.06 2.06-.94-2.06-.94-.94-2.06-.94 2.06-2.06.94zm-11 1L8.5 8.5l.94-2.06 2.06-.94-2.06-.94L8.5 2.5l-.94 2.06-2.06.94zm10 10l.94 2.06.94-2.06 2.06-.94-2.06-.94-.94-2.06-.94 2.06-2.06.94z"/><path d="M17.41 7.96l-1.37-1.37c-.4-.4-.92-.59-1.43-.59-.52 0-1.04.2-1.43.59L10.3 9.45l-7.72 7.72c-.78.78-.78 2.05 0 2.83L4 21.41c.39.39.9.59 1.41.59.51 0 1.02-.2 1.41-.59l7.78-7.78 2.81-2.81c.8-.78.8-2.07 0-2.86zM5.41 20L4 18.59l7.72-7.72 1.47 1.35L5.41 20z"/>
  </svg>
      </button>

  <style>
    .colab-df-container {
      display:flex;
      flex-wrap:wrap;
      gap: 12px;
    }

    .colab-df-convert {
      background-color: #E8F0FE;
      border: none;
      border-radius: 50%;
      cursor: pointer;
      display: none;
      fill: #1967D2;
      height: 32px;
      padding: 0 0 0 0;
      width: 32px;
    }

    .colab-df-convert:hover {
      background-color: #E2EBFA;
      box-shadow: 0px 1px 2px rgba(60, 64, 67, 0.3), 0px 1px 3px 1px rgba(60, 64, 67, 0.15);
      fill: #174EA6;
    }

    [theme=dark] .colab-df-convert {
      background-color: #3B4455;
      fill: #D2E3FC;
    }

    [theme=dark] .colab-df-convert:hover {
      background-color: #434B5C;
      box-shadow: 0px 1px 3px 1px rgba(0, 0, 0, 0.15);
      filter: drop-shadow(0px 1px 2px rgba(0, 0, 0, 0.3));
      fill: #FFFFFF;
    }
  </style>

      <script>
        const buttonEl =
          document.querySelector('#df-f33bd0af-5042-4df9-8a76-9c43faa6938b button.colab-df-convert');
        buttonEl.style.display =
          google.colab.kernel.accessAllowed ? 'block' : 'none';

        async function convertToInteractive(key) {
          const element = document.querySelector('#df-f33bd0af-5042-4df9-8a76-9c43faa6938b');
          const dataTable =
            await google.colab.kernel.invokeFunction('convertToInteractive',
                                                     [key], {});
          if (!dataTable) return;

          const docLinkHtml = 'Like what you see? Visit the ' +
            '<a target="_blank" href=https://colab.research.google.com/notebooks/data_table.ipynb>data table notebook</a>'
            + ' to learn more about interactive tables.';
          element.innerHTML = '';
          dataTable['output_type'] = 'display_data';
          await google.colab.output.renderOutput(dataTable, element);
          const docLink = document.createElement('div');
          docLink.innerHTML = docLinkHtml;
          element.appendChild(docLink);
        }
      </script>
    </div>
  </div>





```python
predictor_new_features = TabularPredictor(
    label='count', 
    problem_type='regression', 
    eval_metric='root_mean_squared_error'
    ).fit(
    train_data=df_train_new_features, 
    time_limit=600, 
    presets='best_quality', 
    )
```

    No path specified. Models will be saved in: "AutogluonModels/ag-20230522_155903/"
    Presets specified: ['best_quality']
    Stack configuration (auto_stack=True): num_stack_levels=1, num_bag_folds=8, num_bag_sets=20
    Beginning AutoGluon training ... Time limit = 600s
    AutoGluon will save models to "AutogluonModels/ag-20230522_155903/"
    AutoGluon Version:  0.7.0
    Python Version:     3.10.11
    Operating System:   Linux
    Platform Machine:   x86_64
    Platform Version:   #1 SMP Sat Apr 29 09:15:28 UTC 2023
    Train Data Rows:    10886
    Train Data Columns: 10
    Label Column: count
    Preprocessing data ...
    Using Feature Generators to preprocess the data ...
    Fitting AutoMLPipelineFeatureGenerator...
    	Available Memory:                    10949.72 MB
    	Train Data (Original)  Memory Usage: 0.72 MB (0.0% of available memory)
    	Inferring data type of each feature based on column values. Set feature_metadata_in to manually specify special dtypes of the features.
    	Stage 1 Generators:
    		Fitting AsTypeFeatureGenerator...
    			Note: Converting 2 features to boolean dtype as they only contain 2 unique values.
    	Stage 2 Generators:
    		Fitting FillNaFeatureGenerator...
    	Stage 3 Generators:
    		Fitting IdentityFeatureGenerator...
    		Fitting CategoryFeatureGenerator...
    			Fitting CategoryMemoryMinimizeFeatureGenerator...
    		Fitting DatetimeFeatureGenerator...
    	Stage 4 Generators:
    		Fitting DropUniqueFeatureGenerator...
    	Types of features in original data (raw dtype, special dtypes):
    		('category', []) : 2 | ['season', 'weather']
    		('datetime', []) : 1 | ['datetime']
    		('float', [])    : 3 | ['temp', 'atemp', 'windspeed']
    		('int', [])      : 4 | ['holiday', 'workingday', 'humidity', 'hour']
    	Types of features in processed data (raw dtype, special dtypes):
    		('category', [])             : 2 | ['season', 'weather']
    		('float', [])                : 3 | ['temp', 'atemp', 'windspeed']
    		('int', [])                  : 2 | ['humidity', 'hour']
    		('int', ['bool'])            : 2 | ['holiday', 'workingday']
    		('int', ['datetime_as_int']) : 5 | ['datetime', 'datetime.year', 'datetime.month', 'datetime.day', 'datetime.dayofweek']
    	0.3s = Fit runtime
    	10 features in original data used to generate 14 features in processed data.
    	Train Data (Processed) Memory Usage: 0.92 MB (0.0% of available memory)
    Data preprocessing and feature engineering runtime = 0.31s ...
    AutoGluon will gauge predictive performance using evaluation metric: 'root_mean_squared_error'
    	This metric's sign has been flipped to adhere to being higher_is_better. The metric score can be multiplied by -1 to get the metric value.
    	To change this, specify the eval_metric parameter of Predictor()
    AutoGluon will fit 2 stack levels (L1 to L2) ...
    Fitting 11 L1 models ...
    Fitting model: KNeighborsUnif_BAG_L1 ... Training model for up to 399.69s of the 599.68s of remaining time.
    	-101.5462	 = Validation score   (-root_mean_squared_error)
    	0.09s	 = Training   runtime
    	0.1s	 = Validation runtime
    Fitting model: KNeighborsDist_BAG_L1 ... Training model for up to 399.42s of the 599.41s of remaining time.
    	-84.1251	 = Validation score   (-root_mean_squared_error)
    	0.07s	 = Training   runtime
    	0.12s	 = Validation runtime
    Fitting model: LightGBMXT_BAG_L1 ... Training model for up to 399.16s of the 599.15s of remaining time.
    	Fitting 8 child models (S1F1 - S1F8) | Fitting with ParallelLocalFoldFittingStrategy
    	-34.4573	 = Validation score   (-root_mean_squared_error)
    	159.32s	 = Training   runtime
    	40.51s	 = Validation runtime
    Fitting model: LightGBM_BAG_L1 ... Training model for up to 174.45s of the 374.43s of remaining time.
    	Fitting 8 child models (S1F1 - S1F8) | Fitting with ParallelLocalFoldFittingStrategy
    	-33.9196	 = Validation score   (-root_mean_squared_error)
    	68.25s	 = Training   runtime
    	8.56s	 = Validation runtime
    Fitting model: RandomForestMSE_BAG_L1 ... Training model for up to 100.6s of the 300.58s of remaining time.
    	-38.4543	 = Validation score   (-root_mean_squared_error)
    	21.18s	 = Training   runtime
    	1.0s	 = Validation runtime
    Fitting model: CatBoost_BAG_L1 ... Training model for up to 77.06s of the 277.05s of remaining time.
    	Fitting 8 child models (S1F1 - S1F8) | Fitting with ParallelLocalFoldFittingStrategy
    	-37.892	 = Validation score   (-root_mean_squared_error)
    	87.86s	 = Training   runtime
    	0.24s	 = Validation runtime
    Completed 1/20 k-fold bagging repeats ...
    Fitting model: WeightedEnsemble_L2 ... Training model for up to 360.0s of the 185.11s of remaining time.
    	-32.3477	 = Validation score   (-root_mean_squared_error)
    	0.74s	 = Training   runtime
    	0.0s	 = Validation runtime
    Fitting 9 L2 models ...
    Fitting model: LightGBMXT_BAG_L2 ... Training model for up to 184.3s of the 184.27s of remaining time.
    	Fitting 8 child models (S1F1 - S1F8) | Fitting with ParallelLocalFoldFittingStrategy
    	-31.1116	 = Validation score   (-root_mean_squared_error)
    	55.66s	 = Training   runtime
    	3.15s	 = Validation runtime
    Fitting model: LightGBM_BAG_L2 ... Training model for up to 121.31s of the 121.28s of remaining time.
    	Fitting 8 child models (S1F1 - S1F8) | Fitting with ParallelLocalFoldFittingStrategy
    	-30.598	 = Validation score   (-root_mean_squared_error)
    	41.35s	 = Training   runtime
    	0.62s	 = Validation runtime
    Fitting model: RandomForestMSE_BAG_L2 ... Training model for up to 69.74s of the 69.72s of remaining time.
    	-31.9412	 = Validation score   (-root_mean_squared_error)
    	45.52s	 = Training   runtime
    	1.1s	 = Validation runtime
    Fitting model: CatBoost_BAG_L2 ... Training model for up to 21.7s of the 21.67s of remaining time.
    	Fitting 8 child models (S1F1 - S1F8) | Fitting with ParallelLocalFoldFittingStrategy
    	-31.8552	 = Validation score   (-root_mean_squared_error)
    	38.0s	 = Training   runtime
    	0.32s	 = Validation runtime
    Completed 1/20 k-fold bagging repeats ...
    Fitting model: WeightedEnsemble_L3 ... Training model for up to 360.0s of the -24.82s of remaining time.
    	-30.3494	 = Validation score   (-root_mean_squared_error)
    	0.54s	 = Training   runtime
    	0.0s	 = Validation runtime
    AutoGluon training complete, total runtime = 625.41s ... Best model: "WeightedEnsemble_L3"
    TabularPredictor saved. To load, use: predictor = TabularPredictor.load("AutogluonModels/ag-20230522_155903/")



```python
predictor_new_features.fit_summary()
```

    *** Summary of fit() ***
    Estimated performance of each model:
                         model   score_val  pred_time_val    fit_time  pred_time_val_marginal  fit_time_marginal  stack_level  can_infer  fit_order
    0      WeightedEnsemble_L3  -30.349428      55.728584  517.842358                0.001722           0.535095            3       True         12
    1          LightGBM_BAG_L2  -30.597970      51.159071  378.120597                0.623195          41.351601            2       True          9
    2        LightGBMXT_BAG_L2  -31.111623      53.689969  392.433553                3.154093          55.664557            2       True          8
    3          CatBoost_BAG_L2  -31.855185      50.853901  374.766423                0.318025          37.997427            2       True         11
    4   RandomForestMSE_BAG_L2  -31.941208      51.631549  382.293678                1.095673          45.524682            2       True         10
    5      WeightedEnsemble_L2  -32.347654      50.436282  337.412818                0.003002           0.738272            2       True          7
    6          LightGBM_BAG_L1  -33.919639       8.560926   68.249186                8.560926          68.249186            1       True          4
    7        LightGBMXT_BAG_L1  -34.457274      40.513375  159.322437               40.513375         159.322437            1       True          3
    8          CatBoost_BAG_L1  -37.891971       0.237720   87.862094                0.237720          87.862094            1       True          6
    9   RandomForestMSE_BAG_L1  -38.454338       0.997438   21.175493                0.997438          21.175493            1       True          5
    10   KNeighborsDist_BAG_L1  -84.125061       0.123821    0.065336                0.123821           0.065336            1       True          2
    11   KNeighborsUnif_BAG_L1 -101.546199       0.102597    0.094450                0.102597           0.094450            1       True          1
    Number of models trained: 12
    Types of models trained:
    {'StackerEnsembleModel_CatBoost', 'WeightedEnsembleModel', 'StackerEnsembleModel_KNN', 'StackerEnsembleModel_RF', 'StackerEnsembleModel_LGB'}
    Bagging used: True  (with 8 folds)
    Multi-layer stack-ensembling used: True  (with 3 levels)
    Feature Metadata (Processed):
    (raw dtype, special dtypes):
    ('category', [])             : 2 | ['season', 'weather']
    ('float', [])                : 3 | ['temp', 'atemp', 'windspeed']
    ('int', [])                  : 2 | ['humidity', 'hour']
    ('int', ['bool'])            : 2 | ['holiday', 'workingday']
    ('int', ['datetime_as_int']) : 5 | ['datetime', 'datetime.year', 'datetime.month', 'datetime.day', 'datetime.dayofweek']
    *** End of fit() summary ***


    /usr/local/lib/python3.10/dist-packages/autogluon/core/utils/plots.py:138: UserWarning: AutoGluon summary plots cannot be created because bokeh is not installed. To see plots, please do: "pip install bokeh==2.0.1"
      warnings.warn('AutoGluon summary plots cannot be created because bokeh is not installed. To see plots, please do: "pip install bokeh==2.0.1"')





    {'model_types': {'KNeighborsUnif_BAG_L1': 'StackerEnsembleModel_KNN',
      'KNeighborsDist_BAG_L1': 'StackerEnsembleModel_KNN',
      'LightGBMXT_BAG_L1': 'StackerEnsembleModel_LGB',
      'LightGBM_BAG_L1': 'StackerEnsembleModel_LGB',
      'RandomForestMSE_BAG_L1': 'StackerEnsembleModel_RF',
      'CatBoost_BAG_L1': 'StackerEnsembleModel_CatBoost',
      'WeightedEnsemble_L2': 'WeightedEnsembleModel',
      'LightGBMXT_BAG_L2': 'StackerEnsembleModel_LGB',
      'LightGBM_BAG_L2': 'StackerEnsembleModel_LGB',
      'RandomForestMSE_BAG_L2': 'StackerEnsembleModel_RF',
      'CatBoost_BAG_L2': 'StackerEnsembleModel_CatBoost',
      'WeightedEnsemble_L3': 'WeightedEnsembleModel'},
     'model_performance': {'KNeighborsUnif_BAG_L1': -101.54619908446061,
      'KNeighborsDist_BAG_L1': -84.12506123181602,
      'LightGBMXT_BAG_L1': -34.457273921492806,
      'LightGBM_BAG_L1': -33.919639163586254,
      'RandomForestMSE_BAG_L1': -38.4543378929385,
      'CatBoost_BAG_L1': -37.8919712004946,
      'WeightedEnsemble_L2': -32.34765396524193,
      'LightGBMXT_BAG_L2': -31.111622817608666,
      'LightGBM_BAG_L2': -30.59797032609257,
      'RandomForestMSE_BAG_L2': -31.94120783919731,
      'CatBoost_BAG_L2': -31.855184633806694,
      'WeightedEnsemble_L3': -30.3494282070515},
     'model_best': 'WeightedEnsemble_L3',
     'model_paths': {'KNeighborsUnif_BAG_L1': 'AutogluonModels/ag-20230522_155903/models/KNeighborsUnif_BAG_L1/',
      'KNeighborsDist_BAG_L1': 'AutogluonModels/ag-20230522_155903/models/KNeighborsDist_BAG_L1/',
      'LightGBMXT_BAG_L1': 'AutogluonModels/ag-20230522_155903/models/LightGBMXT_BAG_L1/',
      'LightGBM_BAG_L1': 'AutogluonModels/ag-20230522_155903/models/LightGBM_BAG_L1/',
      'RandomForestMSE_BAG_L1': 'AutogluonModels/ag-20230522_155903/models/RandomForestMSE_BAG_L1/',
      'CatBoost_BAG_L1': 'AutogluonModels/ag-20230522_155903/models/CatBoost_BAG_L1/',
      'WeightedEnsemble_L2': 'AutogluonModels/ag-20230522_155903/models/WeightedEnsemble_L2/',
      'LightGBMXT_BAG_L2': 'AutogluonModels/ag-20230522_155903/models/LightGBMXT_BAG_L2/',
      'LightGBM_BAG_L2': 'AutogluonModels/ag-20230522_155903/models/LightGBM_BAG_L2/',
      'RandomForestMSE_BAG_L2': 'AutogluonModels/ag-20230522_155903/models/RandomForestMSE_BAG_L2/',
      'CatBoost_BAG_L2': 'AutogluonModels/ag-20230522_155903/models/CatBoost_BAG_L2/',
      'WeightedEnsemble_L3': 'AutogluonModels/ag-20230522_155903/models/WeightedEnsemble_L3/'},
     'model_fit_times': {'KNeighborsUnif_BAG_L1': 0.09444999694824219,
      'KNeighborsDist_BAG_L1': 0.06533551216125488,
      'LightGBMXT_BAG_L1': 159.3224368095398,
      'LightGBM_BAG_L1': 68.24918627738953,
      'RandomForestMSE_BAG_L1': 21.175493478775024,
      'CatBoost_BAG_L1': 87.86209416389465,
      'WeightedEnsemble_L2': 0.7382717132568359,
      'LightGBMXT_BAG_L2': 55.66455698013306,
      'LightGBM_BAG_L2': 41.351601123809814,
      'RandomForestMSE_BAG_L2': 45.52468204498291,
      'CatBoost_BAG_L2': 37.997426986694336,
      'WeightedEnsemble_L3': 0.5350949764251709},
     'model_pred_times': {'KNeighborsUnif_BAG_L1': 0.10259723663330078,
      'KNeighborsDist_BAG_L1': 0.12382054328918457,
      'LightGBMXT_BAG_L1': 40.51337456703186,
      'LightGBM_BAG_L1': 8.560925960540771,
      'RandomForestMSE_BAG_L1': 0.9974381923675537,
      'CatBoost_BAG_L1': 0.23772001266479492,
      'WeightedEnsemble_L2': 0.0030024051666259766,
      'LightGBMXT_BAG_L2': 3.154092788696289,
      'LightGBM_BAG_L2': 0.6231949329376221,
      'RandomForestMSE_BAG_L2': 1.095672607421875,
      'CatBoost_BAG_L2': 0.3180246353149414,
      'WeightedEnsemble_L3': 0.001722097396850586},
     'num_bag_folds': 8,
     'max_stack_level': 3,
     'model_hyperparams': {'KNeighborsUnif_BAG_L1': {'use_orig_features': True,
       'max_base_models': 25,
       'max_base_models_per_type': 5,
       'save_bag_folds': True,
       'use_child_oof': True},
      'KNeighborsDist_BAG_L1': {'use_orig_features': True,
       'max_base_models': 25,
       'max_base_models_per_type': 5,
       'save_bag_folds': True,
       'use_child_oof': True},
      'LightGBMXT_BAG_L1': {'use_orig_features': True,
       'max_base_models': 25,
       'max_base_models_per_type': 5,
       'save_bag_folds': True},
      'LightGBM_BAG_L1': {'use_orig_features': True,
       'max_base_models': 25,
       'max_base_models_per_type': 5,
       'save_bag_folds': True},
      'RandomForestMSE_BAG_L1': {'use_orig_features': True,
       'max_base_models': 25,
       'max_base_models_per_type': 5,
       'save_bag_folds': True,
       'use_child_oof': True},
      'CatBoost_BAG_L1': {'use_orig_features': True,
       'max_base_models': 25,
       'max_base_models_per_type': 5,
       'save_bag_folds': True},
      'WeightedEnsemble_L2': {'use_orig_features': False,
       'max_base_models': 25,
       'max_base_models_per_type': 5,
       'save_bag_folds': True},
      'LightGBMXT_BAG_L2': {'use_orig_features': True,
       'max_base_models': 25,
       'max_base_models_per_type': 5,
       'save_bag_folds': True},
      'LightGBM_BAG_L2': {'use_orig_features': True,
       'max_base_models': 25,
       'max_base_models_per_type': 5,
       'save_bag_folds': True},
      'RandomForestMSE_BAG_L2': {'use_orig_features': True,
       'max_base_models': 25,
       'max_base_models_per_type': 5,
       'save_bag_folds': True,
       'use_child_oof': True},
      'CatBoost_BAG_L2': {'use_orig_features': True,
       'max_base_models': 25,
       'max_base_models_per_type': 5,
       'save_bag_folds': True},
      'WeightedEnsemble_L3': {'use_orig_features': False,
       'max_base_models': 25,
       'max_base_models_per_type': 5,
       'save_bag_folds': True}},
     'leaderboard':                      model   score_val  pred_time_val    fit_time  \
     0      WeightedEnsemble_L3  -30.349428      55.728584  517.842358   
     1          LightGBM_BAG_L2  -30.597970      51.159071  378.120597   
     2        LightGBMXT_BAG_L2  -31.111623      53.689969  392.433553   
     3          CatBoost_BAG_L2  -31.855185      50.853901  374.766423   
     4   RandomForestMSE_BAG_L2  -31.941208      51.631549  382.293678   
     5      WeightedEnsemble_L2  -32.347654      50.436282  337.412818   
     6          LightGBM_BAG_L1  -33.919639       8.560926   68.249186   
     7        LightGBMXT_BAG_L1  -34.457274      40.513375  159.322437   
     8          CatBoost_BAG_L1  -37.891971       0.237720   87.862094   
     9   RandomForestMSE_BAG_L1  -38.454338       0.997438   21.175493   
     10   KNeighborsDist_BAG_L1  -84.125061       0.123821    0.065336   
     11   KNeighborsUnif_BAG_L1 -101.546199       0.102597    0.094450   
     
         pred_time_val_marginal  fit_time_marginal  stack_level  can_infer  \
     0                 0.001722           0.535095            3       True   
     1                 0.623195          41.351601            2       True   
     2                 3.154093          55.664557            2       True   
     3                 0.318025          37.997427            2       True   
     4                 1.095673          45.524682            2       True   
     5                 0.003002           0.738272            2       True   
     6                 8.560926          68.249186            1       True   
     7                40.513375         159.322437            1       True   
     8                 0.237720          87.862094            1       True   
     9                 0.997438          21.175493            1       True   
     10                0.123821           0.065336            1       True   
     11                0.102597           0.094450            1       True   
     
         fit_order  
     0          12  
     1           9  
     2           8  
     3          11  
     4          10  
     5           7  
     6           4  
     7           3  
     8           6  
     9           5  
     10          2  
     11          1  }




```python
predictor_new_features.leaderboard(df_train_new_features, silent=True).plot(kind='bar', x='model', y='score_val')
```




    <Axes: xlabel='model'>




    
![png](output_58_1.png)
    



```python
# Remember to set all negative values to zero
predictions_new_features = predictor_new_features.predict(test, as_pandas=True)
```


```python
(predictions_new_features < 0).sum()
```




    0




```python
predictions_new_features[predictions_new_features < 0] = 0
```


```python
# Same submitting predictions
submission_new_features = pd.read_csv('submission.csv')
submission_new_features["count"] = predictions_new_features
submission_new_features.to_csv("submission_new_features.csv", index=False)
```


```python
!kaggle competitions submit -c bike-sharing-demand -f submission_new_features.csv -m "new features"
```

    100% 188k/188k [00:01<00:00, 156kB/s]
    Successfully submitted to Bike Sharing Demand


```python
!kaggle competitions submissions -c bike-sharing-demand | tail -n +1 | head -n 6
```

    fileName                     date                 description           status    publicScore  privateScore  
    ---------------------------  -------------------  --------------------  --------  -----------  ------------  
    submission_new_features.csv  2023-05-22 16:15:44  new features          complete  0.64160      0.64160       
    submission.csv               2023-05-22 15:56:20  first raw submission  complete  1.80405      1.80405       


#### New Score of 0.64160

## Step 6: Hyper parameter optimization
* There are many options for hyper parameter optimization.
* Options are to change the AutoGluon higher level parameters or the individual model hyperparameters.
* The hyperparameters of the models themselves that are in AutoGluon. Those need the `hyperparameter` and `hyperparameter_tune_kwargs` arguments.


```python
import autogluon.core as ag
# hyperparameter settings
gbm_options = {
    'num_boost_round' : ag.space.Int(lower=100, upper=500, default=100),
    'num_leaves' : ag.space.Int(lower=6, upper=10),
    'learning_rate' : ag.space.Real(lower=0.01, upper=0.3, log=True)
}


cat_options = {
    'iterations' : 100,
    'learning_rate' : ag.space.Real(lower=0.01, upper=0.3, log=True),
    'depth' : ag.space.Int(lower=6, upper=10)
}
xgb_options = {
    'n_estimators' : ag.space.Int(lower=100, upper=500, default=100),
    'max_depth' : ag.space.Int(lower=6, upper=10, default=6),
    'eta' : ag.space.Real(lower=0.01, upper=0.3, log=True)
}

```


```python
# Choosing specific hyperparameter options
# Models : GBM, CAT, XGB, RF, XT, KNN, LR, NN_MXNET, NN_TORCH
hyperparameters = {
    'XGB' : xgb_options,
    'GBM' : gbm_options,
    'CAT' : cat_options
}

num_trials = 5
search_strategy = 'random'

hyperparameter_tune_kwargs = {
    'num_trials' : num_trials,
    'scheduler' : 'local',
    'searcher' : search_strategy
}
```


```python
predictor_new_hpo = TabularPredictor(
    label='count', 
    problem_type='regression', 
    eval_metric='root_mean_squared_error',
    path='AutogluonModels/xgb_gbm_cat_tuning_v1'
    ).fit(
    train_data=df_train_new_features, 
    time_limit=600, 
    presets='best_quality',
    hyperparameters=hyperparameters,
    hyperparameter_tune_kwargs=hyperparameter_tune_kwargs,
    )
```

    Warning: path already exists! This predictor may overwrite an existing predictor! path="AutogluonModels/xgb_gbm_cat_tuning_v1"
    Presets specified: ['best_quality']
    Warning: hyperparameter tuning is currently experimental and may cause the process to hang.
    Stack configuration (auto_stack=True): num_stack_levels=1, num_bag_folds=8, num_bag_sets=20
    Beginning AutoGluon training ... Time limit = 600s
    AutoGluon will save models to "AutogluonModels/xgb_gbm_cat_tuning_v1/"
    AutoGluon Version:  0.7.0
    Python Version:     3.10.11
    Operating System:   Linux
    Platform Machine:   x86_64
    Platform Version:   #1 SMP Sat Apr 29 09:15:28 UTC 2023
    Train Data Rows:    10886
    Train Data Columns: 10
    Label Column: count
    Preprocessing data ...
    Using Feature Generators to preprocess the data ...
    Fitting AutoMLPipelineFeatureGenerator...
    	Available Memory:                    11215.6 MB
    	Train Data (Original)  Memory Usage: 0.72 MB (0.0% of available memory)
    	Inferring data type of each feature based on column values. Set feature_metadata_in to manually specify special dtypes of the features.
    	Stage 1 Generators:
    		Fitting AsTypeFeatureGenerator...
    			Note: Converting 2 features to boolean dtype as they only contain 2 unique values.
    	Stage 2 Generators:
    		Fitting FillNaFeatureGenerator...
    	Stage 3 Generators:
    		Fitting IdentityFeatureGenerator...
    		Fitting CategoryFeatureGenerator...
    			Fitting CategoryMemoryMinimizeFeatureGenerator...
    		Fitting DatetimeFeatureGenerator...
    	Stage 4 Generators:
    		Fitting DropUniqueFeatureGenerator...
    	Types of features in original data (raw dtype, special dtypes):
    		('category', []) : 2 | ['season', 'weather']
    		('datetime', []) : 1 | ['datetime']
    		('float', [])    : 3 | ['temp', 'atemp', 'windspeed']
    		('int', [])      : 4 | ['holiday', 'workingday', 'humidity', 'hour']
    	Types of features in processed data (raw dtype, special dtypes):
    		('category', [])             : 2 | ['season', 'weather']
    		('float', [])                : 3 | ['temp', 'atemp', 'windspeed']
    		('int', [])                  : 2 | ['humidity', 'hour']
    		('int', ['bool'])            : 2 | ['holiday', 'workingday']
    		('int', ['datetime_as_int']) : 5 | ['datetime', 'datetime.year', 'datetime.month', 'datetime.day', 'datetime.dayofweek']
    	0.2s = Fit runtime
    	10 features in original data used to generate 14 features in processed data.
    	Train Data (Processed) Memory Usage: 0.92 MB (0.0% of available memory)
    Data preprocessing and feature engineering runtime = 0.2s ...
    AutoGluon will gauge predictive performance using evaluation metric: 'root_mean_squared_error'
    	This metric's sign has been flipped to adhere to being higher_is_better. The metric score can be multiplied by -1 to get the metric value.
    	To change this, specify the eval_metric parameter of Predictor()
    AutoGluon will fit 2 stack levels (L1 to L2) ...
    Fitting 3 L1 models ...
    Hyperparameter tuning model: LightGBM_BAG_L1 ... Tuning model for up to 119.93s of the 599.8s of remaining time.



      0%|          | 0/5 [00:00<?, ?it/s]


    	Fitting 8 child models (S1F1 - S1F8) | Fitting with ParallelLocalFoldFittingStrategy
    	Fitting 8 child models (S1F1 - S1F8) | Fitting with ParallelLocalFoldFittingStrategy
    	Stopping HPO to satisfy time limit...
    Fitted model: LightGBM_BAG_L1/T1 ...
    	-123.3311	 = Validation score   (-root_mean_squared_error)
    	39.61s	 = Training   runtime
    	0.0s	 = Validation runtime
    Fitted model: LightGBM_BAG_L1/T2 ...
    	-39.1758	 = Validation score   (-root_mean_squared_error)
    	45.06s	 = Training   runtime
    	0.0s	 = Validation runtime
    Hyperparameter tuning model: CatBoost_BAG_L1 ... Tuning model for up to 119.93s of the 514.97s of remaining time.



      0%|          | 0/5 [00:00<?, ?it/s]


    	Fitting 8 child models (S1F1 - S1F8) | Fitting with ParallelLocalFoldFittingStrategy
    	Fitting 8 child models (S1F1 - S1F8) | Fitting with ParallelLocalFoldFittingStrategy
    	Stopping HPO to satisfy time limit...
    Fitted model: CatBoost_BAG_L1/T1 ...
    	-112.9033	 = Validation score   (-root_mean_squared_error)
    	36.75s	 = Training   runtime
    	0.0s	 = Validation runtime
    Fitted model: CatBoost_BAG_L1/T2 ...
    	-36.0601	 = Validation score   (-root_mean_squared_error)
    	46.39s	 = Training   runtime
    	0.0s	 = Validation runtime
    Hyperparameter tuning model: XGBoost_BAG_L1 ... Tuning model for up to 119.93s of the 431.69s of remaining time.



      0%|          | 0/5 [00:00<?, ?it/s]


    	Fitting 8 child models (S1F1 - S1F8) | Fitting with ParallelLocalFoldFittingStrategy
    	Fitting 8 child models (S1F1 - S1F8) | Fitting with ParallelLocalFoldFittingStrategy
    	Fitting 8 child models (S1F1 - S1F8) | Fitting with ParallelLocalFoldFittingStrategy
    	Stopping HPO to satisfy time limit...
    Fitted model: XGBoost_BAG_L1/T1 ...
    	-38.0755	 = Validation score   (-root_mean_squared_error)
    	30.18s	 = Training   runtime
    	0.0s	 = Validation runtime
    Fitted model: XGBoost_BAG_L1/T2 ...
    	-35.8635	 = Validation score   (-root_mean_squared_error)
    	49.41s	 = Training   runtime
    	0.0s	 = Validation runtime
    Fitted model: XGBoost_BAG_L1/T3 ...
    	-35.0334	 = Validation score   (-root_mean_squared_error)
    	49.02s	 = Training   runtime
    	0.0s	 = Validation runtime
    Completed 1/20 k-fold bagging repeats ...
    Fitting model: WeightedEnsemble_L2 ... Training model for up to 360.0s of the 302.88s of remaining time.
    	-33.7945	 = Validation score   (-root_mean_squared_error)
    	0.69s	 = Training   runtime
    	0.0s	 = Validation runtime
    Fitting 3 L2 models ...
    Hyperparameter tuning model: LightGBM_BAG_L2 ... Tuning model for up to 90.65s of the 302.14s of remaining time.



      0%|          | 0/5 [00:00<?, ?it/s]


    	Fitting 8 child models (S1F1 - S1F8) | Fitting with ParallelLocalFoldFittingStrategy
    	Fitting 8 child models (S1F1 - S1F8) | Fitting with ParallelLocalFoldFittingStrategy
    	Stopping HPO to satisfy time limit...
    Fitted model: LightGBM_BAG_L2/T1 ...
    	-76.712	 = Validation score   (-root_mean_squared_error)
    	40.38s	 = Training   runtime
    	0.0s	 = Validation runtime
    Fitted model: LightGBM_BAG_L2/T2 ...
    	-34.0126	 = Validation score   (-root_mean_squared_error)
    	41.66s	 = Training   runtime
    	0.0s	 = Validation runtime
    Hyperparameter tuning model: CatBoost_BAG_L2 ... Tuning model for up to 90.65s of the 219.92s of remaining time.



      0%|          | 0/5 [00:00<?, ?it/s]


    	Fitting 8 child models (S1F1 - S1F8) | Fitting with ParallelLocalFoldFittingStrategy
    	Fitting 8 child models (S1F1 - S1F8) | Fitting with ParallelLocalFoldFittingStrategy
    	Stopping HPO to satisfy time limit...
    Fitted model: CatBoost_BAG_L2/T1 ...
    	-77.9626	 = Validation score   (-root_mean_squared_error)
    	38.87s	 = Training   runtime
    	0.0s	 = Validation runtime
    Fitted model: CatBoost_BAG_L2/T2 ...
    	-34.6952	 = Validation score   (-root_mean_squared_error)
    	68.35s	 = Training   runtime
    	0.0s	 = Validation runtime
    Hyperparameter tuning model: XGBoost_BAG_L2 ... Tuning model for up to 90.65s of the 112.49s of remaining time.



      0%|          | 0/5 [00:00<?, ?it/s]


    	Fitting 8 child models (S1F1 - S1F8) | Fitting with ParallelLocalFoldFittingStrategy
    	Fitting 8 child models (S1F1 - S1F8) | Fitting with ParallelLocalFoldFittingStrategy
    	Stopping HPO to satisfy time limit...
    Fitted model: XGBoost_BAG_L2/T1 ...
    	-34.6899	 = Validation score   (-root_mean_squared_error)
    	37.98s	 = Training   runtime
    	0.0s	 = Validation runtime
    Fitted model: XGBoost_BAG_L2/T2 ...
    	-34.9682	 = Validation score   (-root_mean_squared_error)
    	58.71s	 = Training   runtime
    	0.0s	 = Validation runtime
    Completed 1/20 k-fold bagging repeats ...
    Fitting model: WeightedEnsemble_L3 ... Training model for up to 360.0s of the 15.63s of remaining time.
    	-33.8273	 = Validation score   (-root_mean_squared_error)
    	0.53s	 = Training   runtime
    	0.0s	 = Validation runtime
    AutoGluon training complete, total runtime = 584.94s ... Best model: "WeightedEnsemble_L2"
    TabularPredictor saved. To load, use: predictor = TabularPredictor.load("AutogluonModels/xgb_gbm_cat_tuning_v1/")



```python
predictor_new_hpo.fit_summary(verbosity=3)
```

    *** Summary of fit() ***
    Estimated performance of each model:
                      model   score_val  pred_time_val    fit_time  pred_time_val_marginal  fit_time_marginal  stack_level  can_infer  fit_order
    0   WeightedEnsemble_L2  -33.794456       0.001861  145.507394                0.001371           0.686822            2       True          8
    1   WeightedEnsemble_L3  -33.827269       0.004970  503.657226                0.001535           0.528773            3       True         15
    2    LightGBM_BAG_L2/T2  -34.012635       0.001388  338.086319                0.000177          41.660851            2       True         10
    3     XGBoost_BAG_L2/T1  -34.689921       0.001384  334.409030                0.000173          37.983562            2       True         13
    4    CatBoost_BAG_L2/T2  -34.695225       0.001374  364.773736                0.000164          68.348268            2       True         12
    5     XGBoost_BAG_L2/T2  -34.968216       0.002921  355.135773                0.001710          58.710305            2       True         14
    6     XGBoost_BAG_L1/T3  -35.033404       0.000158   49.023582                0.000158          49.023582            1       True          7
    7     XGBoost_BAG_L1/T2  -35.863486       0.000174   49.409616                0.000174          49.409616            1       True          6
    8    CatBoost_BAG_L1/T2  -36.060110       0.000158   46.387375                0.000158          46.387375            1       True          4
    9     XGBoost_BAG_L1/T1  -38.075542       0.000219   30.179128                0.000219          30.179128            1       True          5
    10   LightGBM_BAG_L1/T2  -39.175818       0.000159   45.058444                0.000159          45.058444            1       True          2
    11   LightGBM_BAG_L2/T1  -76.712038       0.001347  336.803394                0.000136          40.377926            2       True          9
    12   CatBoost_BAG_L2/T1  -77.962599       0.001366  335.292742                0.000155          38.867273            2       True         11
    13   CatBoost_BAG_L1/T1 -112.903265       0.000172   36.753779                0.000172          36.753779            1       True          3
    14   LightGBM_BAG_L1/T1 -123.331068       0.000169   39.613545                0.000169          39.613545            1       True          1
    Number of models trained: 15
    Types of models trained:
    {'StackerEnsembleModel_CatBoost', 'StackerEnsembleModel_LGB', 'WeightedEnsembleModel', 'StackerEnsembleModel_XGBoost'}
    Bagging used: True  (with 8 folds)
    Multi-layer stack-ensembling used: True  (with 3 levels)
    Feature Metadata (Processed):
    (raw dtype, special dtypes):
    ('category', [])             : 2 | ['season', 'weather']
    ('float', [])                : 3 | ['temp', 'atemp', 'windspeed']
    ('int', [])                  : 2 | ['humidity', 'hour']
    ('int', ['bool'])            : 2 | ['holiday', 'workingday']
    ('int', ['datetime_as_int']) : 5 | ['datetime', 'datetime.year', 'datetime.month', 'datetime.day', 'datetime.dayofweek']
    *** End of fit() summary ***


    /usr/local/lib/python3.10/dist-packages/autogluon/core/utils/plots.py:138: UserWarning: AutoGluon summary plots cannot be created because bokeh is not installed. To see plots, please do: "pip install bokeh==2.0.1"
      warnings.warn('AutoGluon summary plots cannot be created because bokeh is not installed. To see plots, please do: "pip install bokeh==2.0.1"')





    {'model_types': {'LightGBM_BAG_L1/T1': 'StackerEnsembleModel_LGB',
      'LightGBM_BAG_L1/T2': 'StackerEnsembleModel_LGB',
      'CatBoost_BAG_L1/T1': 'StackerEnsembleModel_CatBoost',
      'CatBoost_BAG_L1/T2': 'StackerEnsembleModel_CatBoost',
      'XGBoost_BAG_L1/T1': 'StackerEnsembleModel_XGBoost',
      'XGBoost_BAG_L1/T2': 'StackerEnsembleModel_XGBoost',
      'XGBoost_BAG_L1/T3': 'StackerEnsembleModel_XGBoost',
      'WeightedEnsemble_L2': 'WeightedEnsembleModel',
      'LightGBM_BAG_L2/T1': 'StackerEnsembleModel_LGB',
      'LightGBM_BAG_L2/T2': 'StackerEnsembleModel_LGB',
      'CatBoost_BAG_L2/T1': 'StackerEnsembleModel_CatBoost',
      'CatBoost_BAG_L2/T2': 'StackerEnsembleModel_CatBoost',
      'XGBoost_BAG_L2/T1': 'StackerEnsembleModel_XGBoost',
      'XGBoost_BAG_L2/T2': 'StackerEnsembleModel_XGBoost',
      'WeightedEnsemble_L3': 'WeightedEnsembleModel'},
     'model_performance': {'LightGBM_BAG_L1/T1': -123.33106763728148,
      'LightGBM_BAG_L1/T2': -39.17581752664111,
      'CatBoost_BAG_L1/T1': -112.90326523305363,
      'CatBoost_BAG_L1/T2': -36.060109873759664,
      'XGBoost_BAG_L1/T1': -38.075542185472464,
      'XGBoost_BAG_L1/T2': -35.86348597710704,
      'XGBoost_BAG_L1/T3': -35.0334041934223,
      'WeightedEnsemble_L2': -33.79445593351771,
      'LightGBM_BAG_L2/T1': -76.71203783751119,
      'LightGBM_BAG_L2/T2': -34.012635437407596,
      'CatBoost_BAG_L2/T1': -77.96259945654893,
      'CatBoost_BAG_L2/T2': -34.695225408793576,
      'XGBoost_BAG_L2/T1': -34.68992129948954,
      'XGBoost_BAG_L2/T2': -34.96821596499692,
      'WeightedEnsemble_L3': -33.82726949598288},
     'model_best': 'WeightedEnsemble_L2',
     'model_paths': {'LightGBM_BAG_L1/T1': '/content/AutogluonModels/xgb_gbm_cat_tuning_v1/models/LightGBM_BAG_L1/T1/',
      'LightGBM_BAG_L1/T2': '/content/AutogluonModels/xgb_gbm_cat_tuning_v1/models/LightGBM_BAG_L1/T2/',
      'CatBoost_BAG_L1/T1': '/content/AutogluonModels/xgb_gbm_cat_tuning_v1/models/CatBoost_BAG_L1/T1/',
      'CatBoost_BAG_L1/T2': '/content/AutogluonModels/xgb_gbm_cat_tuning_v1/models/CatBoost_BAG_L1/T2/',
      'XGBoost_BAG_L1/T1': '/content/AutogluonModels/xgb_gbm_cat_tuning_v1/models/XGBoost_BAG_L1/T1/',
      'XGBoost_BAG_L1/T2': '/content/AutogluonModels/xgb_gbm_cat_tuning_v1/models/XGBoost_BAG_L1/T2/',
      'XGBoost_BAG_L1/T3': '/content/AutogluonModels/xgb_gbm_cat_tuning_v1/models/XGBoost_BAG_L1/T3/',
      'WeightedEnsemble_L2': 'AutogluonModels/xgb_gbm_cat_tuning_v1/models/WeightedEnsemble_L2/',
      'LightGBM_BAG_L2/T1': '/content/AutogluonModels/xgb_gbm_cat_tuning_v1/models/LightGBM_BAG_L2/T1/',
      'LightGBM_BAG_L2/T2': '/content/AutogluonModels/xgb_gbm_cat_tuning_v1/models/LightGBM_BAG_L2/T2/',
      'CatBoost_BAG_L2/T1': '/content/AutogluonModels/xgb_gbm_cat_tuning_v1/models/CatBoost_BAG_L2/T1/',
      'CatBoost_BAG_L2/T2': '/content/AutogluonModels/xgb_gbm_cat_tuning_v1/models/CatBoost_BAG_L2/T2/',
      'XGBoost_BAG_L2/T1': '/content/AutogluonModels/xgb_gbm_cat_tuning_v1/models/XGBoost_BAG_L2/T1/',
      'XGBoost_BAG_L2/T2': '/content/AutogluonModels/xgb_gbm_cat_tuning_v1/models/XGBoost_BAG_L2/T2/',
      'WeightedEnsemble_L3': 'AutogluonModels/xgb_gbm_cat_tuning_v1/models/WeightedEnsemble_L3/'},
     'model_fit_times': {'LightGBM_BAG_L1/T1': 39.613544940948486,
      'LightGBM_BAG_L1/T2': 45.058444023132324,
      'CatBoost_BAG_L1/T1': 36.75377893447876,
      'CatBoost_BAG_L1/T2': 46.38737511634827,
      'XGBoost_BAG_L1/T1': 30.17912793159485,
      'XGBoost_BAG_L1/T2': 49.4096155166626,
      'XGBoost_BAG_L1/T3': 49.023581743240356,
      'WeightedEnsemble_L2': 0.6868219375610352,
      'LightGBM_BAG_L2/T1': 40.377925634384155,
      'LightGBM_BAG_L2/T2': 41.660850524902344,
      'CatBoost_BAG_L2/T1': 38.86727333068848,
      'CatBoost_BAG_L2/T2': 68.3482677936554,
      'XGBoost_BAG_L2/T1': 37.983561515808105,
      'XGBoost_BAG_L2/T2': 58.710304975509644,
      'WeightedEnsemble_L3': 0.528773307800293},
     'model_pred_times': {'LightGBM_BAG_L1/T1': 0.00016927719116210938,
      'LightGBM_BAG_L1/T2': 0.00015926361083984375,
      'CatBoost_BAG_L1/T1': 0.0001723766326904297,
      'CatBoost_BAG_L1/T2': 0.0001583099365234375,
      'XGBoost_BAG_L1/T1': 0.00021910667419433594,
      'XGBoost_BAG_L1/T2': 0.0001742839813232422,
      'XGBoost_BAG_L1/T3': 0.00015783309936523438,
      'WeightedEnsemble_L2': 0.0013709068298339844,
      'LightGBM_BAG_L2/T1': 0.00013637542724609375,
      'LightGBM_BAG_L2/T2': 0.00017714500427246094,
      'CatBoost_BAG_L2/T1': 0.0001552104949951172,
      'CatBoost_BAG_L2/T2': 0.00016355514526367188,
      'XGBoost_BAG_L2/T1': 0.00017333030700683594,
      'XGBoost_BAG_L2/T2': 0.0017104148864746094,
      'WeightedEnsemble_L3': 0.0015347003936767578},
     'num_bag_folds': 8,
     'max_stack_level': 3,
     'model_hyperparams': {'LightGBM_BAG_L1/T1': {'use_orig_features': True,
       'max_base_models': 25,
       'max_base_models_per_type': 5,
       'save_bag_folds': True},
      'LightGBM_BAG_L1/T2': {'use_orig_features': True,
       'max_base_models': 25,
       'max_base_models_per_type': 5,
       'save_bag_folds': True},
      'CatBoost_BAG_L1/T1': {'use_orig_features': True,
       'max_base_models': 25,
       'max_base_models_per_type': 5,
       'save_bag_folds': True},
      'CatBoost_BAG_L1/T2': {'use_orig_features': True,
       'max_base_models': 25,
       'max_base_models_per_type': 5,
       'save_bag_folds': True},
      'XGBoost_BAG_L1/T1': {'use_orig_features': True,
       'max_base_models': 25,
       'max_base_models_per_type': 5,
       'save_bag_folds': True},
      'XGBoost_BAG_L1/T2': {'use_orig_features': True,
       'max_base_models': 25,
       'max_base_models_per_type': 5,
       'save_bag_folds': True},
      'XGBoost_BAG_L1/T3': {'use_orig_features': True,
       'max_base_models': 25,
       'max_base_models_per_type': 5,
       'save_bag_folds': True},
      'WeightedEnsemble_L2': {'use_orig_features': False,
       'max_base_models': 25,
       'max_base_models_per_type': 5,
       'save_bag_folds': True},
      'LightGBM_BAG_L2/T1': {'use_orig_features': True,
       'max_base_models': 25,
       'max_base_models_per_type': 5,
       'save_bag_folds': True},
      'LightGBM_BAG_L2/T2': {'use_orig_features': True,
       'max_base_models': 25,
       'max_base_models_per_type': 5,
       'save_bag_folds': True},
      'CatBoost_BAG_L2/T1': {'use_orig_features': True,
       'max_base_models': 25,
       'max_base_models_per_type': 5,
       'save_bag_folds': True},
      'CatBoost_BAG_L2/T2': {'use_orig_features': True,
       'max_base_models': 25,
       'max_base_models_per_type': 5,
       'save_bag_folds': True},
      'XGBoost_BAG_L2/T1': {'use_orig_features': True,
       'max_base_models': 25,
       'max_base_models_per_type': 5,
       'save_bag_folds': True},
      'XGBoost_BAG_L2/T2': {'use_orig_features': True,
       'max_base_models': 25,
       'max_base_models_per_type': 5,
       'save_bag_folds': True},
      'WeightedEnsemble_L3': {'use_orig_features': False,
       'max_base_models': 25,
       'max_base_models_per_type': 5,
       'save_bag_folds': True}},
     'leaderboard':                   model   score_val  pred_time_val    fit_time  \
     0   WeightedEnsemble_L2  -33.794456       0.001861  145.507394   
     1   WeightedEnsemble_L3  -33.827269       0.004970  503.657226   
     2    LightGBM_BAG_L2/T2  -34.012635       0.001388  338.086319   
     3     XGBoost_BAG_L2/T1  -34.689921       0.001384  334.409030   
     4    CatBoost_BAG_L2/T2  -34.695225       0.001374  364.773736   
     5     XGBoost_BAG_L2/T2  -34.968216       0.002921  355.135773   
     6     XGBoost_BAG_L1/T3  -35.033404       0.000158   49.023582   
     7     XGBoost_BAG_L1/T2  -35.863486       0.000174   49.409616   
     8    CatBoost_BAG_L1/T2  -36.060110       0.000158   46.387375   
     9     XGBoost_BAG_L1/T1  -38.075542       0.000219   30.179128   
     10   LightGBM_BAG_L1/T2  -39.175818       0.000159   45.058444   
     11   LightGBM_BAG_L2/T1  -76.712038       0.001347  336.803394   
     12   CatBoost_BAG_L2/T1  -77.962599       0.001366  335.292742   
     13   CatBoost_BAG_L1/T1 -112.903265       0.000172   36.753779   
     14   LightGBM_BAG_L1/T1 -123.331068       0.000169   39.613545   
     
         pred_time_val_marginal  fit_time_marginal  stack_level  can_infer  \
     0                 0.001371           0.686822            2       True   
     1                 0.001535           0.528773            3       True   
     2                 0.000177          41.660851            2       True   
     3                 0.000173          37.983562            2       True   
     4                 0.000164          68.348268            2       True   
     5                 0.001710          58.710305            2       True   
     6                 0.000158          49.023582            1       True   
     7                 0.000174          49.409616            1       True   
     8                 0.000158          46.387375            1       True   
     9                 0.000219          30.179128            1       True   
     10                0.000159          45.058444            1       True   
     11                0.000136          40.377926            2       True   
     12                0.000155          38.867273            2       True   
     13                0.000172          36.753779            1       True   
     14                0.000169          39.613545            1       True   
     
         fit_order  
     0           8  
     1          15  
     2          10  
     3          13  
     4          12  
     5          14  
     6           7  
     7           6  
     8           4  
     9           5  
     10          2  
     11          9  
     12         11  
     13          3  
     14          1  }




```python
predictor_new_hpo.leaderboard(df_train_new_features, silent=True).plot(kind='bar', x='model', y='score_val')
```




    <Axes: xlabel='model'>




    
![png](output_71_1.png)
    



```python
# Remember to set all negative values to zero
predictions_new_hpo = predictor_new_hpo.predict(test, as_pandas=True)
```


```python
(predictions_new_hpo < 0).sum()
```




    71




```python
predictions_new_hpo[predictions_new_hpo < 0] = 0
```


```python
# Same submitting predictions
submission_new_hpo = submission
submission_new_hpo["count"] = predictions_new_hpo
# # testing rounding predictions
# submission_new_hpo['count'] = submission_new_hpo["count"].astype('int64')
submission_new_hpo.to_csv("submission_new_hpo_cat_gbm_xgb_2.csv", index=False)
```


```python
!kaggle competitions submit -c bike-sharing-demand -f submission_new_hpo_cat_gbm_xgb_2.csv -m "new features with hyperparameters cat xgb gbm 2 rounded"
```

    100% 188k/188k [00:00<00:00, 255kB/s]
    Successfully submitted to Bike Sharing Demand


```python
!kaggle competitions submissions -c bike-sharing-demand | tail -n +1 | head -n 6
```

    fileName                              date                 description                                              status    publicScore  privateScore  
    ------------------------------------  -------------------  -------------------------------------------------------  --------  -----------  ------------  
    submission_new_hpo_cat_gbm_xgb_2.csv  2023-05-22 16:24:11  new features with hyperparameters cat xgb gbm 2 rounded  complete  0.54003      0.54003       
    submission_new_features.csv           2023-05-22 16:15:44  new features                                             complete  0.64160      0.64160       
    submission.csv                        2023-05-22 15:56:20  first raw submission                                     complete  1.80405      1.80405       


#### New Score of 0.54003

## Step 7: Write a Report
### Refer to the markdown file for the full report
### Creating plots and table for report


```python
# Taking the top model score from each training run and creating a line plot to show improvement
# You can create these in the notebook and save them to PNG or use some other tool (e.g. google sheets, excel)
fig = pd.DataFrame(
    {
        "model": ["initial", "add_features", "hpo"],
        "score": [48.086 , 55.72 , 0.1861]
    }
).plot(x="model", y="score", figsize=(8, 6)).get_figure()
fig.savefig('model_train_score.png')
```


    
![png](output_80_0.png)
    



```python
# Take the 3 kaggle scores and creating a line plot to show improvement
fig = pd.DataFrame(
    {
        "test_eval": ["initial", "add_features", "hpo"],
        "score": [1.80405, 0.6416, 0.54003]
    }
).plot(x="test_eval", y="score", figsize=(8, 6)).get_figure()
fig.savefig('model_test_score.png')
```


    
![png](output_81_0.png)
    


### Hyperparameter table


```python
# The 3 hyperparameters we tuned with the kaggle score as the result
table_df = pd.DataFrame({
    "model": ["initial", "add_features", "hpo"],
    "hpo1": [
        'default_vals', 
        'default_vals', 
        'GBM (Light gradient boosting) : num_boost_round: [lower=100, upper=500], num_leaves:[lower=6, upper=10], learning_rate:[lower=0.01, upper=0.3, log scale], applying random search with 5 trials'
        ],
    "hpo2": [
        'default_vals', 
        'default_vals', 
        'XGB (XGBoost): n_estimators : [lower=100, upper=500], max_depth : [lower=6, upper=10], eta (learning_rate) : [lower=0.01, upper=0.3, log scale] applying random search with 5 trials'
        ],
    "hpo3": [
        'default_vals', 
        'default_vals', 
        'CAT (CATBoost) : iterations : 100, depth : [lower=6, upper=10], learning_rate  : [lower=0.01, upper=0.3, log scale] applying random search with 5 trials'
    ],
    "score": [1.80405, 0.6416, 0.54003]
})

table_df
```





  <div id="df-8353dbea-61af-4796-b924-d221f35f851b">
    <div class="colab-df-container">
      <div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>model</th>
      <th>hpo1</th>
      <th>hpo2</th>
      <th>hpo3</th>
      <th>score</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>initial</td>
      <td>default_vals</td>
      <td>default_vals</td>
      <td>default_vals</td>
      <td>1.80405</td>
    </tr>
    <tr>
      <th>1</th>
      <td>add_features</td>
      <td>default_vals</td>
      <td>default_vals</td>
      <td>default_vals</td>
      <td>0.64160</td>
    </tr>
    <tr>
      <th>2</th>
      <td>hpo</td>
      <td>GBM (Light gradient boosting) : num_boost_roun...</td>
      <td>XGB (XGBoost): n_estimators : [lower=100, uppe...</td>
      <td>CAT (CATBoost) : iterations : 100, depth : [lo...</td>
      <td>0.54003</td>
    </tr>
  </tbody>
</table>
</div>
      <button class="colab-df-convert" onclick="convertToInteractive('df-8353dbea-61af-4796-b924-d221f35f851b')"
              title="Convert this dataframe to an interactive table."
              style="display:none;">

  <svg xmlns="http://www.w3.org/2000/svg" height="24px"viewBox="0 0 24 24"
       width="24px">
    <path d="M0 0h24v24H0V0z" fill="none"/>
    <path d="M18.56 5.44l.94 2.06.94-2.06 2.06-.94-2.06-.94-.94-2.06-.94 2.06-2.06.94zm-11 1L8.5 8.5l.94-2.06 2.06-.94-2.06-.94L8.5 2.5l-.94 2.06-2.06.94zm10 10l.94 2.06.94-2.06 2.06-.94-2.06-.94-.94-2.06-.94 2.06-2.06.94z"/><path d="M17.41 7.96l-1.37-1.37c-.4-.4-.92-.59-1.43-.59-.52 0-1.04.2-1.43.59L10.3 9.45l-7.72 7.72c-.78.78-.78 2.05 0 2.83L4 21.41c.39.39.9.59 1.41.59.51 0 1.02-.2 1.41-.59l7.78-7.78 2.81-2.81c.8-.78.8-2.07 0-2.86zM5.41 20L4 18.59l7.72-7.72 1.47 1.35L5.41 20z"/>
  </svg>
      </button>

  <style>
    .colab-df-container {
      display:flex;
      flex-wrap:wrap;
      gap: 12px;
    }

    .colab-df-convert {
      background-color: #E8F0FE;
      border: none;
      border-radius: 50%;
      cursor: pointer;
      display: none;
      fill: #1967D2;
      height: 32px;
      padding: 0 0 0 0;
      width: 32px;
    }

    .colab-df-convert:hover {
      background-color: #E2EBFA;
      box-shadow: 0px 1px 2px rgba(60, 64, 67, 0.3), 0px 1px 3px 1px rgba(60, 64, 67, 0.15);
      fill: #174EA6;
    }

    [theme=dark] .colab-df-convert {
      background-color: #3B4455;
      fill: #D2E3FC;
    }

    [theme=dark] .colab-df-convert:hover {
      background-color: #434B5C;
      box-shadow: 0px 1px 3px 1px rgba(0, 0, 0, 0.15);
      filter: drop-shadow(0px 1px 2px rgba(0, 0, 0, 0.3));
      fill: #FFFFFF;
    }
  </style>

      <script>
        const buttonEl =
          document.querySelector('#df-8353dbea-61af-4796-b924-d221f35f851b button.colab-df-convert');
        buttonEl.style.display =
          google.colab.kernel.accessAllowed ? 'block' : 'none';

        async function convertToInteractive(key) {
          const element = document.querySelector('#df-8353dbea-61af-4796-b924-d221f35f851b');
          const dataTable =
            await google.colab.kernel.invokeFunction('convertToInteractive',
                                                     [key], {});
          if (!dataTable) return;

          const docLinkHtml = 'Like what you see? Visit the ' +
            '<a target="_blank" href=https://colab.research.google.com/notebooks/data_table.ipynb>data table notebook</a>'
            + ' to learn more about interactive tables.';
          element.innerHTML = '';
          dataTable['output_type'] = 'display_data';
          await google.colab.output.renderOutput(dataTable, element);
          const docLink = document.createElement('div');
          docLink.innerHTML = docLinkHtml;
          element.appendChild(docLink);
        }
      </script>
    </div>
  </div>





```python
print(table_df.to_markdown())
```

    |    | model        | hpo1                                                                                                                                                                                            | hpo2                                                                                                                                                                                 | hpo3                                                                                                                                                     |   score |
    |---:|:-------------|:------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|:-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|:---------------------------------------------------------------------------------------------------------------------------------------------------------|--------:|
    |  0 | initial      | default_vals                                                                                                                                                                                    | default_vals                                                                                                                                                                         | default_vals                                                                                                                                             | 1.80405 |
    |  1 | add_features | default_vals                                                                                                                                                                                    | default_vals                                                                                                                                                                         | default_vals                                                                                                                                             | 0.6416  |
    |  2 | hpo          | GBM (Light gradient boosting) : num_boost_round: [lower=100, upper=500], num_leaves:[lower=6, upper=10], learning_rate:[lower=0.01, upper=0.3, log scale], applying random search with 5 trials | XGB (XGBoost): n_estimators : [lower=100, upper=500], max_depth : [lower=6, upper=10], eta (learning_rate) : [lower=0.01, upper=0.3, log scale] applying random search with 5 trials | CAT (CATBoost) : iterations : 100, depth : [lower=6, upper=10], learning_rate  : [lower=0.01, upper=0.3, log scale] applying random search with 5 trials | 0.54003 |

